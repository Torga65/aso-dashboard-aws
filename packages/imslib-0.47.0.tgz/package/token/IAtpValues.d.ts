/**
 * Enum used to store the possible values of the atp field
 */
export declare enum IAtpValues {
    GUEST = "guest"
}
