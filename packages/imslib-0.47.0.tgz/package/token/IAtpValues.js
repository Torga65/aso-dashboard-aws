"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Enum used to store the possible values of the atp field
 */
var IAtpValues;
(function (IAtpValues) {
    IAtpValues["GUEST"] = "guest";
})(IAtpValues = exports.IAtpValues || (exports.IAtpValues = {}));
