/**
 * class used to store the ride errors after a check token call
 */
export declare class RideException {
    /**
     * new redirect url in case of a ride error
     */
    jump: string;
    /**
     * ride error code received during check token
     */
    code: string;
    /**
     * flags RideExceptions thrown as a workaround to the PBA Expired Idle Session issue
     */
    isPbaExpiredIdleSessionWorkaround: boolean;
    constructor(code: string, jump: string, isPbaExpiredIdleSessionWorkaround?: boolean);
}
