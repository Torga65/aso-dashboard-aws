import { IDictionary } from './../facade/IDictionary';
import { ITokenServiceRequest } from '../adobe-ims/facade/ITokenServiceRequest';
import { TokenFields } from './TokenFields';
import { IRefreshTokenResponse } from './IRefreshTokenResponse';
import { FragmentException } from './FragmentException';
import { CsrfService } from '../adobe-ims/csrf/CsrfService';
import { TokenProfileResponse } from '../adobe-ims/TokenProfileResponse';
import { StandaloneToken } from './StandaloneToken';
import { ITokenInformation } from '../adobe-id/custom-types/CustomTypes';
import { AuthorizationCode } from './AuthorizationCode';
import { ModalSignInEvent } from '../token/ModalSignInEvent';
/**
 * class used to store the specific token methods
 */
export declare class TokenService {
    /**
     * local storage instance used to manage with the tokens
     */
    storage: Storage;
    tokenServiceRequest: ITokenServiceRequest;
    private csrfService;
    constructor(tokenServiceRequest: ITokenServiceRequest, csrfService: CsrfService);
    /**
     *
     * @returns {TokenFields} representing the token fields from fragment or local storage
     */
    getTokenFields(): TokenFields | FragmentException | ModalSignInEvent | AuthorizationCode | null;
    /**
     * method used to validate the local storage token value
     */
    validateToken(): Promise<TokenFields>;
    /**
     * method used to retrieve the token release flags
     */
    getReleaseFlags(): Promise<any>;
    /**
     * method used to retrieve the token release flags decoded from B32
     */
    getDecodedReleaseFlags(): Promise<string>;
    /**
     * method used to call the validate token api
     * @param token {String} validate the input token value
     * @param isGuestToken {boolean} whether the token is a guest token or not
     */
    private callValidateTokenApi;
    getGuestToken(externalParameters: {} | undefined, options: {
        enableGuestAccounts?: boolean;
        enableGuestTokenForceRefresh?: boolean;
        enableGuestBotDetection?: boolean;
    }): Promise<TokenProfileResponse>;
    /**
     * tries to get a valid token; if there is no token, the refresh method is called
     * @param externalParameters represents the external parameters used for refresh token
     * @returns TokenProfileResponse
     */
    getTokenAndProfile: (externalParameters?: {}) => Promise<TokenProfileResponse>;
    /**
     * @returns the object values from the url fragment
     */
    getTokenFromFragment(url?: string): TokenFields | FragmentException | ModalSignInEvent | AuthorizationCode | null;
    getItemFromStorage(key: string): string | null;
    /**
     * @returns the TokenFields structure from local storage or null
     * @isReauth boolean value; true if token is for reauthentification
     */
    getTokenFieldsFromStorage(isReauth?: boolean): TokenFields | null;
    /**
     * private method used to compose the key used for storage
     * @param clientId
     * @param scope
     * @param isReAuth default false; true means that the key is for re-authentification
     */
    private getAccessTokenKey;
    /**
     * save the token into local storage
     * @param tokenFragment - object with the values from fragment
     */
    addTokenToStorage(tokenFields: TokenFields): void;
    /**
     * remove the token from local storage
     */
    removeTokenFromLocalStorage(): void;
    /**
     * remove the reauth token from local storage
     */
    removeReauthTokenFromLocalStorage(): void;
    /**
     *
     * @param externalParameters external parameters received outside of the library
     * @returns IRefreshTokenResponse containing the refresh token information
     */
    refreshToken(externalParameters?: IDictionary): Promise<IRefreshTokenResponse>;
    /**
     * function used to change the user profile
     * @param externalParameters external parameters received outside of the library
     * @param userId {String} represents the user id used to get the new token and profile
     * @returns IRefreshTokenResponse containing the refresh token information
     */
    switchProfile(userId: string, externalParameters?: IDictionary): Promise<IRefreshTokenResponse>;
    /**
     *
     * @param externalParameters external parameters received outside of the library
     * @returns IRefreshTokenResponse containing the refresh token information
     */
    private callRefreshToken;
    /**
     * update the token into local storage after a refresh action
     * @param tokenInfo {ITokenInformation}
     *
     */
    updateToken(tokenInfo: ITokenInformation): TokenFields | null;
    /**
     * remove the tokens from the local storage
     */
    purge(): void;
    /**
     * set a new access token
     * @param tokenInfo {StandaloneToken} represents the token and expiration ms
     */
    setStandAloneToken(standaloneToken: StandaloneToken): boolean;
    /**
     * method used during initialization in order to get a ijt token
     * @returns {Promise<TokenProfileResponse>} ijt response
     */
    exchangeIjt(ijt: string): Promise<TokenProfileResponse>;
}
