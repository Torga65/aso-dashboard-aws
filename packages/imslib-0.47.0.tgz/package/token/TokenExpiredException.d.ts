/**
 * class used to encapsulate the token expired message
 */
export declare class TokenExpiredException {
    exception: null;
    constructor(exception: any);
}
