"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable @typescript-eslint/camelcase */
var ApiHelpers_1 = __importDefault(require("../api-helpers/ApiHelpers"));
var Log_1 = __importDefault(require("../log/Log"));
var ScopeUtil_1 = require("../util/ScopeUtil");
var IAtpValues_1 = require("./IAtpValues");
/**
 * class used to store the token fields obtained during validation and validate the token against values from adobeIdData
 */
var TokenFields = /** @class */ (function () {
    /**
     *
     * @param tokenProps {object} represents the server answer for a validation token request
     * @param expire {Date} represents the token expiration date
     *
     * this class is used to create a TokenFields instance based on storage object;
     * if token was saved by ImsLib v1, the token field is stored in access_token property and expiration in 'expiresAtMilliseconds',
     * otherwise, (for imsLIb v2) 'tokenValue' and 'expire' properties are used
     */
    function TokenFields(tokenProps, expire) {
        var _this = this;
        this.REAUTH_SCOPE = 'reauthenticated';
        this.valid = false;
        this.isReauth = function () { return _this.scope.indexOf(_this.REAUTH_SCOPE) >= 0; };
        /**
         * represents the client id associated with this token fields
         */
        this.client_id = '';
        /**
         * represents the scope used to retrieve the token
         */
        this.scope = '';
        /**
         * represents the token expiration date
         */
        this.expire = new Date();
        /**
         * represents the user_id associated with the token
         */
        this.user_id = '';
        this.tokenValue = '';
        /**
         * represents the session identifier
         */
        this.sid = '';
        this.state = null;
        /**
         * true if the token fields is created based on the fragment values and not from storage
         */
        this.fromFragment = false;
        this.impersonatorId = '';
        this.isImpersonatedSession = false;
        var valid = tokenProps.valid, tokenValue = tokenProps.tokenValue, access_token = tokenProps.access_token, state = tokenProps.state, other = tokenProps.other;
        var token = tokenValue || access_token;
        var parsedToken = this.parseJwt(token);
        if (!parsedToken) {
            throw new Error("token cannot be decoded " + token);
        }
        this.state = ApiHelpers_1.default.toJson(state);
        var client_id = parsedToken.client_id, user_id = parsedToken.user_id, tokenScope = parsedToken.scope, sid = parsedToken.sid, imp_id = parsedToken.imp_id, imp_sid = parsedToken.imp_sid, pba = parsedToken.pba, atp = parsedToken.atp, gse = parsedToken.gse;
        this.atp = atp;
        this.client_id = client_id;
        this.expire = expire;
        this.user_id = user_id;
        this.scope = tokenScope;
        this.valid = valid;
        this.tokenValue = token;
        this.sid = sid;
        this.other = other;
        this.impersonatorId = imp_id || '';
        this.isImpersonatedSession = !!imp_sid;
        this.pbaSatisfiedPolicies = pba && pba.split(',') || [];
        this.isGuestToken = this.atp === IAtpValues_1.IAtpValues.GUEST;
        this.gse = gse;
    }
    /**
     * parse the token value
     */
    TokenFields.prototype.parseJwt = function (token) {
        if (!token) {
            return null;
        }
        try {
            return JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
        }
        catch (ex) {
            Log_1.default.error('error on decoding token ', token, ex);
            return null;
        }
    };
    /**
     *
     * @param adobeClientId client id provided on adobe id
     * @param adobeIdScope scope value provided in adobe id
     * @returns {boolean} true if token is valid otherwise false
     */
    TokenFields.prototype.validate = function (adobeClientId, adobeIdScope) {
        var _a = this, valid = _a.valid, client_id = _a.client_id, scope = _a.scope, expire = _a.expire;
        // check if is expired
        if (expire < new Date()) {
            Log_1.default.error('token invalid  --> expires_at', expire);
            return false;
        }
        if (valid != undefined && !valid) {
            Log_1.default.error('token invalid  --> valid');
            return false;
        }
        if (client_id !== adobeClientId) {
            Log_1.default.error('token invalid  --> client id', client_id, adobeClientId);
            return false;
        }
        if (!ScopeUtil_1.validateScopeInclusion(adobeIdScope, scope)) {
            Log_1.default.error('token invalid  --> scope', ' token scope =', scope, 'vs adobeIdScope =', adobeIdScope, '.');
            return false;
        }
        return true;
    };
    return TokenFields;
}());
exports.TokenFields = TokenFields;
