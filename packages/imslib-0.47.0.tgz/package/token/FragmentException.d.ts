import { IFragmentExceptionType } from './IFragmentExceptionType';
export declare class FragmentException {
    message: string;
    type: string;
    constructor(type: IFragmentExceptionType, message: string);
}
