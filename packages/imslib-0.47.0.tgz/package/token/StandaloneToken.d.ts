/**
 * class used to encapsulate the token and expiration ms;
 * this values are passed from outside of the library by using adobeid
 */
export declare class StandaloneToken {
    token: string;
    /**
     * representing the session identifier
     */
    sid: string;
    expirems: number;
    constructor(data: any);
}
