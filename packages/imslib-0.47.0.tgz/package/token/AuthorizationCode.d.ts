/**
 * class used to store the authorization code fields
 */
export declare class AuthorizationCode {
    /**
     * represents the client id associated with this token fields
     */
    client_id: string;
    /**
     * represents the scope used to retrieve the token
     */
    scope: string;
    /**
     * represents the code recived during the authorization
     */
    code: string;
    /**
     * represents the state used during initialize
     */
    state: any;
    /**
     * represents the code_verifier used to generate the code_challenge (used during authorization flow)
     */
    code_verifier: string;
    /**
     * represents the other properties from url
     */
    other: any;
    /**
     * this class is used to create a AuthorizationCode instance based on authorization server response
     * @param authProps {object} represents the authorization server response
     */
    constructor(authProps: any);
}
