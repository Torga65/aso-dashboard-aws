"use strict";
/* eslint-disable @typescript-eslint/camelcase */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var StorageFactory_1 = __importDefault(require("./../storage/StorageFactory"));
var ImsConstants_1 = require("../constants/ImsConstants");
var TokenFields_1 = require("./TokenFields");
var FragmentHelper_1 = __importDefault(require("../url/FragmentHelper"));
var FragmentException_1 = require("./FragmentException");
var IFragmentExceptionType_1 = require("./IFragmentExceptionType");
var TokenProfileResponse_1 = require("../adobe-ims/TokenProfileResponse");
var RideException_1 = require("./RideException");
var TokenExpiredException_1 = require("./TokenExpiredException");
var Log_1 = __importDefault(require("../log/Log"));
var HttpErrorResponse_1 = require("../error-handlers/HttpErrorResponse");
var AuthorizationCode_1 = require("./AuthorizationCode");
var ModalSignInEvent_1 = require("../token/ModalSignInEvent");
var code_challenge_1 = require("../adobe-ims/pkce/code-challenge");
var ScopeUtil_1 = require("../util/ScopeUtil");
var Base32Util_1 = require("../util/Base32Util");
var ArkoseInitialization_1 = require("../arkose-helpers/ArkoseInitialization");
var ArkoseException_1 = require("../arkose-helpers/ArkoseException");
var ALLOWED_FRAGMENT_APIS = ['authorize', 'check_token'];
var LOGOUT_API = 'logout';
var ONE_SECOND_MILLIS = 1000;
/**
 * class used to store the specific token methods
 */
var TokenService = /** @class */ (function () {
    function TokenService(tokenServiceRequest, csrfService) {
        var _this = this;
        /**
         * tries to get a valid token; if there is no token, the refresh method is called
         * @param externalParameters represents the external parameters used for refresh token
         * @returns TokenProfileResponse
         */
        this.getTokenAndProfile = function (externalParameters) {
            if (externalParameters === void 0) { externalParameters = {}; }
            var tokenResponse = _this.getTokenFields();
            if (tokenResponse instanceof ModalSignInEvent_1.ModalSignInEvent) {
                return Promise.reject(tokenResponse);
            }
            if (tokenResponse instanceof FragmentException_1.FragmentException) {
                return Promise.reject(tokenResponse);
            }
            if (tokenResponse instanceof AuthorizationCode_1.AuthorizationCode) {
                var imsApis = _this.tokenServiceRequest.imsApis;
                return imsApis.getTokenFromCode(tokenResponse, externalParameters).then(function (tokenApiResponse) {
                    var access_token = tokenApiResponse.access_token, state = tokenApiResponse.state, expires_in = tokenApiResponse.expires_in, _a = tokenApiResponse.scope, scope = _a === void 0 ? '' : _a, profile = __rest(tokenApiResponse, ["access_token", "state", "expires_in", "scope"]);
                    var tokenFields = new TokenFields_1.TokenFields({
                        scope: scope,
                        tokenValue: access_token,
                        valid: true,
                        state: state,
                        other: tokenResponse.other,
                    }, new Date(new Date().getTime() + parseFloat(expires_in)));
                    return Promise.resolve(new TokenProfileResponse_1.TokenProfileResponse(tokenFields, profile));
                });
            }
            if (tokenResponse instanceof TokenFields_1.TokenFields) {
                if (tokenResponse.fromFragment || !_this.tokenServiceRequest.autoValidateToken) {
                    return Promise.resolve(new TokenProfileResponse_1.TokenProfileResponse(tokenResponse, null));
                }
                return _this.callValidateTokenApi(tokenResponse.tokenValue, tokenResponse.isGuestToken).then(function () { return new TokenProfileResponse_1.TokenProfileResponse(tokenResponse, null); })
                    .catch(function () { return _this.callRefreshToken(externalParameters); });
            }
            else {
                return _this.callRefreshToken(externalParameters);
            }
        };
        var useLocalStorage = tokenServiceRequest.useLocalStorage;
        this.csrfService = csrfService;
        this.tokenServiceRequest = tokenServiceRequest;
        this.storage = StorageFactory_1.default.getStorageByName(useLocalStorage ? ImsConstants_1.STORAGE_MODE.LocalStorage : ImsConstants_1.STORAGE_MODE.SessionStorage);
    }
    /**
     *
     * @returns {TokenFields} representing the token fields from fragment or local storage
     */
    TokenService.prototype.getTokenFields = function () {
        var _a = this.tokenServiceRequest, clientId = _a.clientId, scope = _a.scope;
        var fragmentResult = this.getTokenFromFragment();
        if (fragmentResult instanceof ModalSignInEvent_1.ModalSignInEvent) {
            return fragmentResult;
        }
        if (fragmentResult instanceof FragmentException_1.FragmentException) {
            return fragmentResult;
        }
        if (fragmentResult instanceof AuthorizationCode_1.AuthorizationCode) {
            return fragmentResult;
        }
        if (fragmentResult && fragmentResult.validate(clientId, scope)) {
            fragmentResult.fromFragment = true;
            this.addTokenToStorage(fragmentResult);
            return fragmentResult;
        }
        return this.getTokenFieldsFromStorage();
    };
    /**
     * method used to validate the local storage token value
     */
    TokenService.prototype.validateToken = function () {
        var tokenFields = this.getTokenFieldsFromStorage();
        if (!tokenFields) {
            return Promise.reject(null);
        }
        return this.callValidateTokenApi(tokenFields.tokenValue, tokenFields.isGuestToken);
    };
    /**
     * method used to retrieve the token release flags
     */
    TokenService.prototype.getReleaseFlags = function () {
        var _a = this.tokenServiceRequest, clientId = _a.clientId, imsApis = _a.imsApis;
        var tokenFields = this.getTokenFieldsFromStorage();
        if (!tokenFields) {
            return Promise.reject(null);
        }
        return imsApis.getReleaseFlags({
            token: tokenFields.tokenValue,
            client_id: clientId,
        });
    };
    /**
     * method used to retrieve the token release flags decoded from B32
     */
    TokenService.prototype.getDecodedReleaseFlags = function () {
        return this.getReleaseFlags().then(function (result) { return Base32Util_1.decodeToBitstring(result.releaseFlags, true); });
    };
    /**
     * method used to call the validate token api
     * @param token {String} validate the input token value
     * @param isGuestToken {boolean} whether the token is a guest token or not
     */
    TokenService.prototype.callValidateTokenApi = function (token, isGuestToken) {
        var _this = this;
        if (isGuestToken === void 0) { isGuestToken = false; }
        var _a = this.tokenServiceRequest, clientId = _a.clientId, scope = _a.scope, imsApis = _a.imsApis;
        var validateTokenParameters = {
            client_id: clientId,
            token: token,
            type: isGuestToken ? 'at' : undefined,
        };
        return imsApis.validateToken(validateTokenParameters)
            .then(function (tokenResponseData) {
            Log_1.default.info('validateToken response', tokenResponseData);
            var tokenFields = new TokenFields_1.TokenFields(__assign(__assign({}, tokenResponseData), { tokenValue: token }), new Date(parseFloat(tokenResponseData.expires_at)));
            if (tokenFields.validate(clientId, scope)) {
                _this.addTokenToStorage(tokenFields);
                return Promise.resolve(tokenFields);
            }
            throw new Error('could not validate tokenFields');
        })
            .catch(function (ex) {
            Log_1.default.error('validateToken response', ex);
            if (ex instanceof HttpErrorResponse_1.HttpErrorResponse) {
                return Promise.reject(ex);
            }
            _this.removeTokenFromLocalStorage();
            return Promise.reject(ex);
        });
    };
    TokenService.prototype.getGuestToken = function (externalParameters, options) {
        if (externalParameters === void 0) { externalParameters = {}; }
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var tokenResponse, hasToken, isGuestToken, arkoseSessionToken, error_1, error_2;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        tokenResponse = this.getTokenFields();
                        hasToken = !(tokenResponse instanceof ModalSignInEvent_1.ModalSignInEvent) &&
                            !(tokenResponse instanceof AuthorizationCode_1.AuthorizationCode) &&
                            tokenResponse instanceof TokenFields_1.TokenFields;
                        isGuestToken = hasToken && ((_a = tokenResponse) === null || _a === void 0 ? void 0 : _a.isGuestToken);
                        if (!options.enableGuestAccounts) return [3 /*break*/, 11];
                        arkoseSessionToken = null;
                        if (!options.enableGuestTokenForceRefresh) return [3 /*break*/, 6];
                        if (!(options.enableGuestBotDetection && !hasToken)) return [3 /*break*/, 5];
                        _b.label = 1;
                    case 1:
                        _b.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, ArkoseInitialization_1.ArkoseInitialization.getArkoseInstance().callArkose()];
                    case 2:
                        _b.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        error_1 = _b.sent();
                        // if arkose fails to load, throw an error that the token could not be retrieved
                        throw new ArkoseException_1.ArkoseException(error_1);
                    case 4:
                        // set arkose session token
                        arkoseSessionToken = ArkoseInitialization_1.ArkoseInitialization.getArkoseInstance().getArkoseSessionToken();
                        _b.label = 5;
                    case 5:
                        if (tokenResponse instanceof FragmentException_1.FragmentException && tokenResponse.type === IFragmentExceptionType_1.IFragmentExceptionType.LOGOUT) {
                            return [2 /*return*/, this.callRefreshToken(__assign(__assign({}, externalParameters), { arkoseSessionToken: arkoseSessionToken }))];
                        }
                        if (isGuestToken) {
                            return [2 /*return*/, this.callRefreshToken(__assign(__assign({}, externalParameters), { arkoseSessionToken: arkoseSessionToken }))];
                        }
                        _b.label = 6;
                    case 6:
                        if (!(options.enableGuestBotDetection && !hasToken)) return [3 /*break*/, 11];
                        _b.label = 7;
                    case 7:
                        _b.trys.push([7, 9, , 10]);
                        return [4 /*yield*/, ArkoseInitialization_1.ArkoseInitialization.getArkoseInstance().callArkose()];
                    case 8:
                        _b.sent();
                        return [3 /*break*/, 10];
                    case 9:
                        error_2 = _b.sent();
                        // if arkose fails to load, throw an error that the token could not be retrieved
                        throw new ArkoseException_1.ArkoseException(error_2);
                    case 10:
                        // set arkose session token
                        arkoseSessionToken = ArkoseInitialization_1.ArkoseInitialization.getArkoseInstance().getArkoseSessionToken();
                        return [2 /*return*/, this.getTokenAndProfile(__assign(__assign({}, externalParameters), { arkoseSessionToken: arkoseSessionToken }))];
                    case 11: return [2 /*return*/, this.getTokenAndProfile(externalParameters)];
                }
            });
        });
    };
    /**
     * @returns the object values from the url fragment
     */
    TokenService.prototype.getTokenFromFragment = function (url) {
        var fragmentValues = FragmentHelper_1.default.fragmentToObject(url);
        if (!fragmentValues) {
            return null;
        }
        var token = fragmentValues.access_token, scope = fragmentValues.scope, error = fragmentValues.error, api = fragmentValues.api, _a = fragmentValues.state, state = _a === void 0 ? {} : _a, expires_in = fragmentValues.expires_in, client_id = fragmentValues.client_id, _b = fragmentValues.code, code = _b === void 0 ? '' : _b, other = __rest(fragmentValues, ["access_token", "scope", "error", "api", "state", "expires_in", "client_id", "code"]);
        var _c = state || {}, imslibmodal = _c.imslibmodal, nonce = _c.nonce;
        if (imslibmodal === true) {
            return new ModalSignInEvent_1.ModalSignInEvent(nonce);
        }
        if (LOGOUT_API === api) {
            return new FragmentException_1.FragmentException(IFragmentExceptionType_1.IFragmentExceptionType.LOGOUT, 'logout callback');
        }
        if (!fragmentValues.from_ims) {
            return null;
        }
        if (client_id !== this.tokenServiceRequest.clientId) {
            return null;
        }
        if (error) {
            return new FragmentException_1.FragmentException(IFragmentExceptionType_1.IFragmentExceptionType.FRAGMENT, error);
        }
        if (!ALLOWED_FRAGMENT_APIS.includes(api)) {
            return new FragmentException_1.FragmentException(IFragmentExceptionType_1.IFragmentExceptionType.API_NOT_ALLOWED, "api should be authorize or check token and " + api + " is used");
        }
        var validCsrf = this.csrfService.verify(nonce);
        if (!validCsrf) {
            return new FragmentException_1.FragmentException(IFragmentExceptionType_1.IFragmentExceptionType.CSRF, 'CSRF exception');
        }
        if (code) {
            var codeChallenge = new code_challenge_1.CodeChallenge();
            var verifier = codeChallenge.getVerifierByKey(nonce);
            if (!verifier) {
                throw new Error('no verifier value has been found');
            }
            return new AuthorizationCode_1.AuthorizationCode(__assign(__assign({}, fragmentValues), { verifier: verifier }));
        }
        if (!token) {
            return null;
        }
        var tokenFields = new TokenFields_1.TokenFields({
            client_id: client_id,
            scope: scope,
            tokenValue: token,
            valid: true,
            state: state,
            other: other
        }, new Date(new Date().getTime() + parseFloat(expires_in)));
        return tokenFields;
    };
    TokenService.prototype.getItemFromStorage = function (key) {
        return this.storage.getItem(key);
    };
    /**
     * @returns the TokenFields structure from local storage or null
     * @isReauth boolean value; true if token is for reauthentification
     */
    TokenService.prototype.getTokenFieldsFromStorage = function (isReauth) {
        if (isReauth === void 0) { isReauth = false; }
        var _a = this.tokenServiceRequest, clientId = _a.clientId, scope = _a.scope;
        var tokenStorageKey = this.getAccessTokenKey(isReauth);
        var tokenData = this.getItemFromStorage(tokenStorageKey);
        if (!tokenData) {
            return null;
        }
        var parsedToken = JSON.parse(tokenData);
        var expire = parsedToken.expire ? new Date(Date.parse(parsedToken.expire)) : new Date(parsedToken.expiresAtMilliseconds);
        var tokenFields = new TokenFields_1.TokenFields(parsedToken, expire);
        return tokenFields.validate(clientId, scope) ? tokenFields : null;
    };
    /**
     * private method used to compose the key used for storage
     * @param clientId
     * @param scope
     * @param isReAuth default false; true means that the key is for re-authentification
     */
    TokenService.prototype.getAccessTokenKey = function (isReauth) {
        if (isReauth === void 0) { isReauth = false; }
        var _a = this.tokenServiceRequest, clientId = _a.clientId, scope = _a.scope;
        return ImsConstants_1.TOKEN_STORAGE_KEY + "/" + clientId + "/" + isReauth + "/" + ScopeUtil_1.sortScopes(scope);
    };
    /**
     * save the token into local storage
     * @param tokenFragment - object with the values from fragment
     */
    TokenService.prototype.addTokenToStorage = function (tokenFields) {
        if (!tokenFields) {
            return;
        }
        var isReauth = tokenFields.isReauth();
        var tokenStorageKey = this.getAccessTokenKey(isReauth);
        var clonedTokenFields = __assign({}, tokenFields);
        clonedTokenFields.state = {};
        clonedTokenFields.other = '{}';
        var storagePayload = JSON.stringify(clonedTokenFields);
        this.storage.setItem(tokenStorageKey, storagePayload);
    };
    /**
     * remove the token from local storage
     */
    TokenService.prototype.removeTokenFromLocalStorage = function () {
        var tokenStorageKey = this.getAccessTokenKey();
        this.storage.removeItem(tokenStorageKey);
    };
    /**
     * remove the reauth token from local storage
     */
    TokenService.prototype.removeReauthTokenFromLocalStorage = function () {
        var tokenStorageKey = this.getAccessTokenKey(true);
        this.storage.removeItem(tokenStorageKey);
    };
    /**
     *
     * @param externalParameters external parameters received outside of the library
     * @returns IRefreshTokenResponse containing the refresh token information
     */
    TokenService.prototype.refreshToken = function (externalParameters) {
        var _this = this;
        if (externalParameters === void 0) { externalParameters = {}; }
        var _a = this.tokenServiceRequest, clientId = _a.clientId, imsApis = _a.imsApis, scope = _a.scope;
        var tokenFields = this.getTokenFieldsFromStorage();
        var userId = tokenFields ? tokenFields.user_id : '';
        return imsApis.checkToken({
            client_id: clientId,
            scope: scope,
        }, externalParameters, userId)
            .then(function (data) {
            if (!data) {
                throw new Error('refresh token --> no response');
            }
            var access_token = data.access_token, expires_in = data.expires_in, token_type = data.token_type, error = data.error, _a = data.error_description, error_description = _a === void 0 ? '' : _a, sid = data.sid, profileValues = __rest(data, ["access_token", "expires_in", "token_type", "error", "error_description", "sid"]);
            if (error) {
                throw new Error(error + " " + error_description);
            }
            var profile = Object.keys(profileValues).length ? profileValues : null;
            var tokenInfo = {
                token: access_token,
                expire: new Date(Date.now() + parseFloat(expires_in)),
                token_type: token_type,
                sid: sid,
            };
            var tokenFields = _this.updateToken(tokenInfo) || {};
            var refreshTokenResponse = {
                tokenInfo: __assign(__assign({}, tokenInfo), { impersonatorId: tokenFields.impersonatorId || '', isImpersonatedSession: tokenFields.isImpersonatedSession || false, pbaSatisfiedPolicies: tokenFields.pbaSatisfiedPolicies || [], isGuestToken: tokenFields.isGuestToken, gse: tokenFields.gse }),
                profile: profile
            };
            return Promise.resolve(refreshTokenResponse);
        })
            .catch(function (refreshTokenException) {
            if (refreshTokenException === void 0) { refreshTokenException = {}; }
            if (refreshTokenException instanceof HttpErrorResponse_1.HttpErrorResponse) {
                return Promise.reject(refreshTokenException);
            }
            if (refreshTokenException instanceof RideException_1.RideException) {
                return Promise.reject(refreshTokenException);
            }
            _this.removeTokenFromLocalStorage();
            return Promise.reject(new TokenExpiredException_1.TokenExpiredException(refreshTokenException));
        });
    };
    /**
     * function used to change the user profile
     * @param externalParameters external parameters received outside of the library
     * @param userId {String} represents the user id used to get the new token and profile
     * @returns IRefreshTokenResponse containing the refresh token information
     */
    TokenService.prototype.switchProfile = function (userId, externalParameters) {
        var _this = this;
        if (externalParameters === void 0) { externalParameters = {}; }
        var _a = this.tokenServiceRequest, clientId = _a.clientId, imsApis = _a.imsApis, scope = _a.scope;
        return imsApis.switchProfile({
            client_id: clientId,
            scope: scope,
        }, externalParameters, userId).then(function (data) {
            if (!data) {
                throw new Error('refresh token --> no response');
            }
            var access_token = data.access_token, expires_in = data.expires_in, token_type = data.token_type, error = data.error, _a = data.error_description, error_description = _a === void 0 ? '' : _a, sid = data.sid, profileValues = __rest(data, ["access_token", "expires_in", "token_type", "error", "error_description", "sid"]);
            if (error) {
                throw new Error(error + " " + error_description);
            }
            var profile = Object.keys(profileValues).length ? profileValues : null;
            var tokenInfo = {
                token: access_token,
                expire: new Date(Date.now() + parseFloat(expires_in)),
                token_type: token_type,
                sid: sid,
            };
            var tokenFields = _this.updateToken(tokenInfo) || {};
            var refreshTokenResponse = {
                tokenInfo: __assign(__assign({}, tokenInfo), { impersonatorId: tokenFields.impersonatorId || '', isImpersonatedSession: tokenFields.isImpersonatedSession || false }),
                profile: profile
            };
            return Promise.resolve(refreshTokenResponse);
        })
            .catch(function (switchTokenException) {
            if (switchTokenException === void 0) { switchTokenException = {}; }
            return Promise.reject(switchTokenException);
        });
    };
    /**
     *
     * @param externalParameters external parameters received outside of the library
     * @returns IRefreshTokenResponse containing the refresh token information
     */
    TokenService.prototype.callRefreshToken = function (externalParameters) {
        if (externalParameters === void 0) { externalParameters = {}; }
        return this.refreshToken(externalParameters)
            .then(function (tokenResponse) {
            var _a = tokenResponse.tokenInfo, token = _a.token, expire = _a.expire, profile = tokenResponse.profile;
            var refreshTokenFields = new TokenFields_1.TokenFields({
                valid: true,
                tokenValue: token,
            }, expire);
            var tokenProfileResponse = new TokenProfileResponse_1.TokenProfileResponse(refreshTokenFields, profile);
            return Promise.resolve(tokenProfileResponse);
        })
            .catch(function (ex) {
            return Promise.reject(ex);
        });
    };
    /**
     * update the token into local storage after a refresh action
     * @param tokenInfo {ITokenInformation}
     *
     */
    TokenService.prototype.updateToken = function (tokenInfo) {
        var token = tokenInfo.token, expire = tokenInfo.expire;
        var tokenFields = new TokenFields_1.TokenFields({
            tokenValue: token,
        }, expire);
        if (!tokenFields) {
            return null;
        }
        tokenFields.tokenValue = token;
        this.addTokenToStorage(tokenFields);
        return tokenFields;
    };
    /**
     * remove the tokens from the local storage
     */
    TokenService.prototype.purge = function () {
        this.removeTokenFromLocalStorage();
        this.removeReauthTokenFromLocalStorage();
    };
    /**
     * set a new access token
     * @param tokenInfo {StandaloneToken} represents the token and expiration ms
     */
    TokenService.prototype.setStandAloneToken = function (standaloneToken) {
        var token = standaloneToken.token, sid = standaloneToken.sid, _a = standaloneToken.expirems, expirems = _a === void 0 ? -1 : _a;
        var _b = this.tokenServiceRequest, clientId = _b.clientId, scope = _b.scope;
        var expire = new Date(new Date().getTime() + expirems);
        var tokenFields = new TokenFields_1.TokenFields({
            valid: true,
            tokenValue: token,
        }, expire);
        if (!tokenFields.validate(clientId, scope)) {
            return false;
        }
        var tokenInfoToBeSaved = {
            expire: expire,
            token: token,
            sid: sid,
        };
        this.updateToken(tokenInfoToBeSaved);
        return true;
    };
    /**
     * method used during initialization in order to get a ijt token
     * @returns {Promise<TokenProfileResponse>} ijt response
     */
    TokenService.prototype.exchangeIjt = function (ijt) {
        var _this = this;
        var _a = this.tokenServiceRequest, clientId = _a.clientId, scope = _a.scope, imsApis = _a.imsApis;
        var apiRequest = {
            client_id: clientId,
            scope: scope,
        };
        return imsApis.exchangeIjt(apiRequest, ijt).then(function (ijtResponse) {
            var valid = ijtResponse.valid, access_token = ijtResponse.access_token, expires_in = ijtResponse.expires_in, profile = ijtResponse.profile;
            if (valid === false) {
                return Promise.reject(ijtResponse);
            }
            var expire = new Date(Date.now() + parseFloat(expires_in) * ONE_SECOND_MILLIS);
            var ijtTokenFields = new TokenFields_1.TokenFields({
                valid: true,
                tokenValue: access_token,
            }, expire);
            _this.addTokenToStorage(ijtTokenFields);
            var tokenProfileResponse = new TokenProfileResponse_1.TokenProfileResponse(ijtTokenFields, profile);
            return Promise.resolve(tokenProfileResponse);
        });
    };
    return TokenService;
}());
exports.TokenService = TokenService;
