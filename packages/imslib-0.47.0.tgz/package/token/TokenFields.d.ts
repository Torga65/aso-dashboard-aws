/**
 * class used to store the token fields obtained during validation and validate the token against values from adobeIdData
 */
export declare class TokenFields {
    private REAUTH_SCOPE;
    valid?: boolean | undefined;
    isReauth: () => boolean;
    isGuestToken: boolean;
    /**
     * Represents a token type, this is currently only used for guest tokens
     * but would be added to all tokens in the future.
     */
    atp?: string;
    /**
     * Represents the guest session expiration date (in seconds from Epoch).
     * This value will only be available for guest tokens.
     */
    gse?: number | undefined;
    /**
     * represents the client id associated with this token fields
     */
    client_id: string;
    /**
     * represents the scope used to retrieve the token
     */
    scope: string;
    /**
     * represents the token expiration date
     */
    expire: Date;
    /**
     * represents the user_id associated with the token
     */
    user_id: string;
    tokenValue: string;
    /**
     * represents the session identifier
     */
    sid: string;
    other?: any;
    state: object | null;
    /**
     * true if the token fields is created based on the fragment values and not from storage
     */
    fromFragment: boolean;
    impersonatorId: string;
    isImpersonatedSession: boolean;
    pbaSatisfiedPolicies?: string[];
    /**
     *
     * @param tokenProps {object} represents the server answer for a validation token request
     * @param expire {Date} represents the token expiration date
     *
     * this class is used to create a TokenFields instance based on storage object;
     * if token was saved by ImsLib v1, the token field is stored in access_token property and expiration in 'expiresAtMilliseconds',
     * otherwise, (for imsLIb v2) 'tokenValue' and 'expire' properties are used
     */
    constructor(tokenProps: any, expire: Date);
    /**
     * parse the token value
     */
    private parseJwt;
    /**
     *
     * @param adobeClientId client id provided on adobe id
     * @param adobeIdScope scope value provided in adobe id
     * @returns {boolean} true if token is valid otherwise false
     */
    validate(adobeClientId: string, adobeIdScope: string): boolean;
}
