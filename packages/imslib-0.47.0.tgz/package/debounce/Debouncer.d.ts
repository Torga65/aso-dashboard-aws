/**
 * class used for caching the api calls for a second.
 * The flow is:
 * 1. make api call from ImsLib
 * 2. if the Debouncer cache already contains a response for that api/parameters -> return the cashed response
 *
 */
import { ApiResponse } from '../ims-apis/xhr/ApiResponse';
declare class Debouncer {
    /**
     * debounce time value; one second
     */
    private DEBOUNCE_TIME;
    /**
     * dictionary with all executed methods for the last second
     */
    private cache;
    /**
     * starts to execute a specific API. if there is a cached response, it will be returned
     * @param url - api url
     * @param parameters - represents the parameters used to call the api
     */
    getCachedApiResponse(url: string, parameters?: string): any | null;
    /**
     *
     * @param url {String} - url used to make the api
     * @param bodyParams {String} - the hash associated with the request parameters
     * @param response {ApiResponse} - data received as a http response
     */
    storeApiResponse: (url: string | undefined, bodyParams: string | undefined, response: ApiResponse) => void;
    /**
     *
     * @param url {String} - url used to make the api
     * @param bodyParams {String} - the hash associated with the request parameters
     * @param response {ApiResponse} - data received as a http response
     */
    private cacheApiResponse;
    /**
     * create the timer for a url/hash
     * @param url - {string} - represents the url used to make the http call
     * @param hash {String} - the hash associated with the request parameters
     */
    private createClearCachedDataTimer;
}
declare const _default: Debouncer;
export default _default;
