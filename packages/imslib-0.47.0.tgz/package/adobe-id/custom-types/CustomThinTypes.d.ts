export declare type OnReadyFunction = (applicationState: any) => void;
export declare type RideRedirectFunction = (code: string) => string;
export declare type RideRedirectUri = RideRedirectFunction | string | undefined;
