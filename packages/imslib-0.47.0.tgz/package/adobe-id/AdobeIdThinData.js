"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var ImsConstants_1 = require("../constants/ImsConstants");
var IEnvironment_1 = require("./IEnvironment");
var Environment_1 = __importDefault(require("../adobe-ims/environment/Environment"));
var AnalyticsParameters_1 = require("./AnalyticsParameters");
var Log_1 = __importDefault(require("../log/Log"));
var IReauth_1 = require("../adobe-ims/facade/IReauth");
var IGrantTypes_1 = require("../adobe-ims/facade/IGrantTypes");
var code_challenge_1 = require("../adobe-ims/pkce/code-challenge");
/**
 *  Class used to store the adobe data values.
 *
 *  Ims library will use these values for all operations
 */
var AdobeIdThinData = /** @class */ (function () {
    /**
     * @constructor Create the adobeIdData object with all necessary properties from adobeData input paramater
     *
     * It uses the input adobeData parameter or the object stored in window.adobeid
     */
    function AdobeIdThinData(adobeData) {
        if (adobeData === void 0) { adobeData = null; }
        /**
         * represents the class used to store the analytics parameters
         */
        this.analyticsParameters = new AnalyticsParameters_1.AnalyticsParameters();
        /**
          @property Object containing various custom parameters for IMS.
          This object is used in case a custom API parameter is desired to be sent to the back-end.
      
          E.G. { logout: 'your_custom_value' }
      
          The list of api's which can be customized are: authorize, validate_token, profile, userinfo, logout, logout_token, check, providers, ijt, jumptoken_to_device
        */
        this.api_parameters = {};
        /**
          @property {string} Localization value used by ims library.
      
          Default value is `en_US`
        */
        this.locale = "";
        /**
         * @property {string} - The scopes used to acquire access tokens. A comma separated list of client scopes.
         * No whitespace.
         * Default scopes: AdobeID
         */
        this.scope = "AdobeID";
        /**
         * @property {string} - The client id used by ims library
         */
        this.client_id = "";
        /**
         * represents the used environment; default is prod and in case the value is stg1, the stage environment is used
         */
        this.environment = IEnvironment_1.IEnvironment.PROD;
        /**
         *  use the local storage for token management; default value is false;
         */
        this.useLocalStorage = false;
        this.alwaysRemoveTokenFromUrl = false;
        /** @function {adobeid.onReady} [onReady] - Function to be executed once imslib.js has been fully
         * initialized.
         */
        this.onReady = null;
        this.onModalModeSignInComplete = null;
        this.proxiedCheckToken = false;
        var adobeid = adobeData ? adobeData : window[ImsConstants_1.AdobeIdKey];
        if (!adobeid || !adobeid.client_id) {
            throw new Error("Please provide required adobeId, client_id information");
        }
        var api_parameters = adobeid.api_parameters, client_id = adobeid.client_id, locale = adobeid.locale, scope = adobeid.scope, ijt = adobeid.ijt, _a = adobeid.environment, environment = _a === void 0 ? IEnvironment_1.IEnvironment.PROD : _a, redirect_uri = adobeid.redirect_uri, useLocalStorage = adobeid.useLocalStorage, logsEnabled = adobeid.logsEnabled, onReady = adobeid.onReady, rideRedirectUri = adobeid.rideRedirectUri, proxiedCheckToken = adobeid.proxiedCheckToken;
        this.environment = environment;
        this.api_parameters = api_parameters ? api_parameters : {};
        this.client_id = client_id;
        this.locale = locale || ImsConstants_1.DEFAULT_LANGUAGE;
        this.scope = scope ? scope.replace(/\s/gi, '') : '';
        this.redirect_uri = redirect_uri;
        this.ijt = ijt;
        this.useLocalStorage = useLocalStorage;
        if (logsEnabled) {
            Log_1.default.enableLogging();
        }
        else {
            Log_1.default.disableLogging();
        }
        this.onReady = onReady ? onReady : null;
        this.rideRedirectUri = rideRedirectUri;
        this.proxiedCheckToken = proxiedCheckToken;
        this.fillAnalyticsParameters(adobeid);
        Environment_1.default.loadEnvironment(environment, proxiedCheckToken, window.location.hostname);
    }
    /**
     * fill the analytic parameters with the values provided by adobeid data
     * @param adobeid represents the adobeid data provided to library
     */
    AdobeIdThinData.prototype.fillAnalyticsParameters = function (adobeid) {
        var _a = adobeid.analytics, _b = _a === void 0 ? {} : _a, _c = _b.appCode, appCode = _c === void 0 ? "" : _c, _d = _b.appVersion, appVersion = _d === void 0 ? "" : _d;
        var analyticsParameters = this.analyticsParameters;
        analyticsParameters.appCode = appCode;
        analyticsParameters.appVersion = appVersion;
    };
    /**
     * Function used by IMSLib to use only the neccesarry properties from AdobeIdData for social provider
     * @param providerName provider name used for sign in
     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     */
    AdobeIdThinData.prototype.createSocialProviderRedirectRequest = function (providerName, requestedParameters, contextToBePassedOnRedirect, nonce, grantType) {
        var params = {
            idp_flow: "social.deep_link.web",
            provider_id: providerName,
        };
        var signInParams = __assign(__assign({}, requestedParameters), params);
        return this.createRedirectRequest(signInParams, contextToBePassedOnRedirect, nonce, grantType);
    };
    /**
     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     * @param nonce {string} - string representing the nonce value used for CSRF
     * @param reauth {string}; represents the re authenticate value. available values are: check and force. default value is "check"
     */
    AdobeIdThinData.prototype.createReAuthenticateRedirectRequest = function (requestedParameters, contextToBePassedOnRedirect, nonce, reauth, grantType) {
        if (reauth === void 0) { reauth = IReauth_1.IReauth.check; }
        if (grantType === void 0) { grantType = IGrantTypes_1.IGrantTypes.token; }
        var params = {
            reauth: reauth,
        };
        var reauthParams = __assign(__assign({}, requestedParameters), params);
        return this.createRedirectRequest(reauthParams, contextToBePassedOnRedirect, nonce, grantType);
    };
    /**
     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     */
    AdobeIdThinData.prototype.createSignUpRedirectRequest = function (requestedParameters, contextToBePassedOnRedirect, nonce) {
        var signupParams = __assign(__assign({}, requestedParameters), { idp_flow: "create_account" });
        return this.createRedirectRequest(signupParams, contextToBePassedOnRedirect, nonce, IGrantTypes_1.IGrantTypes.token);
    };
    /**
     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
     * @param externalParameters {Object} the external parameters used for signin and reauth methods
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     * @param nonce {string} - string representing the nonce value used for CSRF
     * @param grantType {IGrantTypes} represents the grant type used for sign in flow
     */
    AdobeIdThinData.prototype.createRedirectRequest = function (externalParameters, contextToBePassedOnRedirect, nonce, grantType) {
        var _this = this;
        var _a = this, _b = _a.api_parameters, apiParameters = _b === void 0 ? {} : _b, clientId = _a.client_id, _c = _a.redirect_uri, adobeIdRedirectUri = _c === void 0 ? '' : _c, scope = _a.scope, locale = _a.locale;
        var state = this.createRedirectState(contextToBePassedOnRedirect, nonce);
        var redirectRequest = {
            adobeIdRedirectUri: adobeIdRedirectUri,
            apiParameters: apiParameters,
            clientId: clientId,
            externalParameters: externalParameters,
            scope: scope,
            locale: locale,
            response_type: grantType,
            state: state,
        };
        if (grantType === IGrantTypes_1.IGrantTypes.token) {
            return Promise.resolve(redirectRequest);
        }
        var codeChallenge = new code_challenge_1.CodeChallenge();
        return codeChallenge.createCodeChallenge(nonce).then(function (challengeResponse) {
            externalParameters.code_challenge = challengeResponse.challenge;
            externalParameters.code_challenge_method = 'S256';
            var codeState = _this.createRedirectState(contextToBePassedOnRedirect, nonce);
            redirectRequest.state = codeState;
            return Promise.resolve(redirectRequest);
        });
    };
    /**
     * create the stae object used during redirect; if the adobeid.context is empty and no analytics parameters, the state will ne null
     * @param context represents the external parameters
     */
    AdobeIdThinData.prototype.createRedirectState = function (context, nonce) {
        var _a = this.analyticsParameters, _b = _a.appCode, appCode = _b === void 0 ? "" : _b, _c = _a.appVersion, appVersion = _c === void 0 ? "" : _c;
        var state = context === undefined
            ? {}
            : {
                context: context,
            };
        if (appCode) {
            state["ac"] = appCode;
        }
        if (appVersion) {
            state["av"] = appVersion;
        }
        state["jslibver"] = Environment_1.default.jslibver;
        state["nonce"] = nonce;
        return Object.keys(state).length ? state : null;
    };
    AdobeIdThinData.prototype.triggerOnReady = function () {
        this.onReady && this.onReady(undefined);
    };
    AdobeIdThinData.prototype.computeRideRedirectUri = function (code) {
        if (!this.rideRedirectUri) {
            return window.location.href;
        }
        if (typeof this.rideRedirectUri === "string") {
            return this.rideRedirectUri === "DEFAULT" ? null : this.rideRedirectUri;
        }
        return this.rideRedirectUri(code);
    };
    return AdobeIdThinData;
}());
exports.AdobeIdThinData = AdobeIdThinData;
