/**
 * Enumeration values for available environments
 */
export declare enum IEnvironment {
    /**
     * Stage environment
     */
    STAGE = "stg1",
    /**
     * Prod environment
     */
    PROD = "prod"
}
