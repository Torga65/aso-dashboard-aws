import { IDictionary } from "../facade/IDictionary";
import { IAdobeIdThinData } from "./IAdobeIdThinData";
import { IRedirectRequest } from "../adobe-ims/facade/IRedirectRequest";
import { IEnvironment } from "./IEnvironment";
import { AnalyticsParameters } from "./AnalyticsParameters";
import { IReauth } from "../adobe-ims/facade/IReauth";
import { IGrantTypes } from "../adobe-ims/facade/IGrantTypes";
import { OnReadyFunction, RideRedirectUri } from "./custom-types/CustomThinTypes";
import { ModalSignInCallbackFunction, OverrideErrorFunction } from "./custom-types/CustomTypes";
/**
 *  Class used to store the adobe data values.
 *
 *  Ims library will use these values for all operations
 */
export declare class AdobeIdThinData implements IAdobeIdThinData {
    /**
     * represents the class used to store the analytics parameters
     */
    analyticsParameters: AnalyticsParameters;
    /**
      @property Object containing various custom parameters for IMS.
      This object is used in case a custom API parameter is desired to be sent to the back-end.
  
      E.G. { logout: 'your_custom_value' }
  
      The list of api's which can be customized are: authorize, validate_token, profile, userinfo, logout, logout_token, check, providers, ijt, jumptoken_to_device
    */
    api_parameters?: {} | undefined;
    /**
      @property {string} Localization value used by ims library.
  
      Default value is `en_US`
    */
    locale: string;
    /**
     * @property {string} - The scopes used to acquire access tokens. A comma separated list of client scopes.
     * No whitespace.
     * Default scopes: AdobeID
     */
    scope: string;
    /**
     * @property {string} - The client id used by ims library
     */
    client_id: string;
    /**
     * represents the used environment; default is prod and in case the value is stg1, the stage environment is used
     */
    environment: IEnvironment;
    /**
     *  use the local storage for token management; default value is false;
     */
    useLocalStorage: boolean;
    /**
     * @property {string} Used as redirect url
     *
     * The redirect uri value is used for signin, signout operations and the used value is the one from external parameters or adobe id data or window.location.href
     */
    redirect_uri: string | (() => string);
    alwaysRemoveTokenFromUrl?: boolean | undefined;
    /** @function {adobeid.onReady} [onReady] - Function to be executed once imslib.js has been fully
     * initialized.
     */
    onReady: OnReadyFunction | null;
    overrideErrorHandler?: OverrideErrorFunction;
    ijt?: string | undefined;
    rideRedirectUri?: RideRedirectUri;
    onModalModeSignInComplete: ModalSignInCallbackFunction | null;
    proxiedCheckToken: boolean;
    /**
     * @constructor Create the adobeIdData object with all necessary properties from adobeData input paramater
     *
     * It uses the input adobeData parameter or the object stored in window.adobeid
     */
    constructor(adobeData?: IAdobeIdThinData | null);
    /**
     * fill the analytic parameters with the values provided by adobeid data
     * @param adobeid represents the adobeid data provided to library
     */
    private fillAnalyticsParameters;
    /**
     * Function used by IMSLib to use only the neccesarry properties from AdobeIdData for social provider
     * @param providerName provider name used for sign in
     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     */
    createSocialProviderRedirectRequest(providerName: string, requestedParameters: IDictionary, contextToBePassedOnRedirect: any, nonce: string, grantType: IGrantTypes): Promise<IRedirectRequest>;
    /**
     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     * @param nonce {string} - string representing the nonce value used for CSRF
     * @param reauth {string}; represents the re authenticate value. available values are: check and force. default value is "check"
     */
    createReAuthenticateRedirectRequest(requestedParameters: IDictionary, contextToBePassedOnRedirect: any, nonce: string, reauth?: IReauth, grantType?: IGrantTypes): Promise<IRedirectRequest>;
    /**
     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     */
    createSignUpRedirectRequest(requestedParameters: IDictionary, contextToBePassedOnRedirect: any, nonce: string): Promise<IRedirectRequest>;
    /**
     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
     * @param externalParameters {Object} the external parameters used for signin and reauth methods
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     * @param nonce {string} - string representing the nonce value used for CSRF
     * @param grantType {IGrantTypes} represents the grant type used for sign in flow
     */
    createRedirectRequest(externalParameters: IDictionary, contextToBePassedOnRedirect: any, nonce: string, grantType: IGrantTypes): Promise<IRedirectRequest>;
    /**
     * create the stae object used during redirect; if the adobeid.context is empty and no analytics parameters, the state will ne null
     * @param context represents the external parameters
     */
    createRedirectState(context: any, nonce: string): any;
    triggerOnReady(): void;
    computeRideRedirectUri(code: string): string | null;
}
