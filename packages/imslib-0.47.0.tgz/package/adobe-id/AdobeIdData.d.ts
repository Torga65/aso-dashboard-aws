import { IDictionary } from "./../facade/IDictionary";
import { IAdobeIdData } from "./IAdobeIdData";
import { IAdobeHandlers } from "./IAdobeHandlers";
import { IRedirectRequest } from "../adobe-ims/facade/IRedirectRequest";
import { PopupSettings } from '../adobe-ims/sign-in/PopupSettings';
import { OnAccessTokenFunction, OnAccessTokenHasExpiredFunction, OnErrorFunction } from "./custom-types/CustomTypes";
import { StandaloneToken } from "../token/StandaloneToken";
import { IReauth } from "../adobe-ims/facade/IReauth";
import { IGrantTypes } from "../adobe-ims/facade/IGrantTypes";
import { AdobeIdThinData } from "./AdobeIdThinData";
/**
 *  Class used to store the adobe data values.
 *
 *  Ims library will use these values for all operations
 */
export declare class AdobeIdData extends AdobeIdThinData implements IAdobeIdData {
    /**
     * if true, the token will be validated against validate token api
     */
    autoValidateToken?: boolean | undefined;
    /**
     * The token use by ims library
     */
    standalone: StandaloneToken | undefined;
    /**
     * modal settings used for sign in with modal
     */
    modalSettings: PopupSettings;
    modalMode?: boolean;
    /** @function {adobeid.onAccessTokenHasExpired} onAccessTokenHasExpired
     *  Function to be executed if the 'access_token' is invalid.
     */
    onAccessTokenHasExpired: OnAccessTokenHasExpiredFunction | null;
    /**  @function {adobeid.onAccessToken} - Function to be executed once imslib.js has acquired
     * an `access_token`.
     */
    onAccessToken: OnAccessTokenFunction | null;
    /**
     * @function {adobeid.onReauthAccessToken} Function used to trigger the reauth access token
     */
    onReauthAccessToken: OnAccessTokenFunction | null;
    /**
     * @function {adobeid.onError}
     * Function used to notify external libraries for ims errors
     */
    onError: OnErrorFunction | null;
    /**
     * if true, imslib will enable support for guest accounts
     */
    enableGuestAccounts?: boolean | undefined;
    /**
     * if true, imslib will always call check token api, instead of validate api, for guest tokens
     */
    enableGuestTokenForceRefresh?: boolean | undefined;
    /**
       * if true, imslib will use arkose to check for bots before requesting a guest token
       */
    enableGuestBotDetection?: boolean | undefined;
    onSignOutEventReceived?: OnAccessTokenHasExpiredFunction | null;
    /**
     * @constructor Create the adobeIdData object with all necessary properties from adobeData input paramater
     *
     * It uses the input adobeData parameter or the object stored in window.adobeid
     */
    constructor(adobeData?: IAdobeIdData | null);
    /**
     * Handlers object is used to invoke the adobe id data events.
     *
     * When a token, profile is aquired, or token is expired and library is fully intialized, an event is triggered
     */
    handlers: IAdobeHandlers;
    /**
     * Function used by IMSLib to use only the neccesarry properties from AdobeIdData for social provider
     * @param providerName provider name used for sign in
     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     */
    createSocialProviderRedirectRequest(providerName: string, requestedParameters: IDictionary, contextToBePassedOnRedirect: any, nonce: string, grantType?: IGrantTypes): Promise<IRedirectRequest>;
    /**
     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     * @param nonce {string} - string representing the nonce value used for CSRF
     * @param reauth {string}; represents the re authenticate value. available values are: check and force. default value is "check"
     */
    createReAuthenticateRedirectRequest(requestedParameters: IDictionary, contextToBePassedOnRedirect: any, nonce: string, reauth?: IReauth, grantType?: IGrantTypes): Promise<IRedirectRequest>;
    /**
     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     */
    createSignUpRedirectRequest(requestedParameters: IDictionary, contextToBePassedOnRedirect: any, nonce: string, grantType?: IGrantTypes): Promise<IRedirectRequest>;
}
