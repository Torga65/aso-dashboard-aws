export declare const AdobeIdKey = "adobeid";
export declare const AdobeIMSKey = "adobeIMS";
export declare const AdobeImsFactory = "adobeImsFactory";
export declare const DEFAULT_LANGUAGE = "en_US";
export declare enum STORAGE_MODE {
    LocalStorage = "local",
    SessionStorage = "session",
    MemoryStorage = "memory"
}
export declare const HEADERS: {
    AUTHORIZATION: string;
    X_IMS_CLIENT_ID: string;
    RETRY_AFTER: string;
};
export declare const PROFILE_STORAGE_KEY = "adobeid_ims_profile";
export declare const TOKEN_STORAGE_KEY = "adobeid_ims_access_token";
export declare const ON_IMSLIB_INSTANCE = "onImsLibInstance";
export declare const ASK_FOR_IMSLIB_INSTANCE_DOM_EVENT_NAME = "getImsLibInstance";
export declare const SETUP_ARKOSE = "setupArkose";
export declare const ARKOSE_PUBLIC_KEY = "BBCC314C-4937-4CCD-B0A3-FDF0F0F7603C";
export declare const ARKOSE_JS_ENDPOINT: string;
