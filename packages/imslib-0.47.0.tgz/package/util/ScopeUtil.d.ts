export declare function sortScopes(scopes: string): string;
export declare function validateScopeInclusion(requestedScope: string, tokenScope: string): boolean;
