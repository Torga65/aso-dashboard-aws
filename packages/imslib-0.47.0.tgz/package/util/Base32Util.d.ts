/**
     * Decodes a base32-encoded string to a bitstring.
     *
     * The function uses the base32 alphabet defined in {@link https://tools.ietf.org/html/rfc4648#page-9|RFC 4648}.
     * This function does not take into account character aliases.
     *
     * @param  {!string} str The base32-encode data
     * @return {!string} A bitstring of the decoded data
     *
     * @throws {Error} If the data contains non-base32 characters
     *
     * @memberof module:base32
     * @public
     */
export declare const decodeToBitstring: (str: string, lsb?: boolean) => string;
