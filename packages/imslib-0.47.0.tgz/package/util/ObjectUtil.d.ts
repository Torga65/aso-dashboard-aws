/**
 * Simple object check.
 * @param item
 * @returns {boolean}
 */
export declare function isObject(item: any): boolean;
/**
   * Deep merge two objects.
   * @param target
   * @param source
   */
export declare function merge(target: any, source: any): any;
