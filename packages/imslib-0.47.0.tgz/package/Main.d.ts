/**
 * Provides the possibility to an external library to create a new instance of AdobeIMS and this class is used as part of
 * the bundle process
 */
declare class Main {
    constructor();
    /**
   * method used only for testing in order to ensure the libray is initialized
   */
    initialize(): boolean;
}
declare const _default: Main;
export default _default;
