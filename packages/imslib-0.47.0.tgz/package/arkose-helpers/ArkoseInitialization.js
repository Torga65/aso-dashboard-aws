"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var ImsConstants_1 = require("../constants/ImsConstants");
var Log_1 = __importDefault(require("../log/Log"));
/**
 * class used to store the Arkose helper functions
 */
var ArkoseInitialization = /** @class */ (function () {
    function ArkoseInitialization() {
        this.arkoseSessionToken = null;
    }
    ArkoseInitialization.getArkoseInstance = function () {
        if (!this.arkoseInstance) {
            ArkoseInitialization.arkoseInstance = new ArkoseInitialization();
        }
        return ArkoseInitialization.arkoseInstance;
    };
    ArkoseInitialization.prototype.getArkoseSessionToken = function () {
        return this.arkoseSessionToken;
    };
    ArkoseInitialization.prototype.setArkoseSessionToken = function (sessionToken) {
        this.arkoseSessionToken = sessionToken;
    };
    /**
     * This method is used to add a script tag into the client page and load the Arkose script
     */
    ArkoseInitialization.prototype.callArkose = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            // add the init function to the window object
            // this function is called by arkose when everything is loaded and available
            window[ImsConstants_1.SETUP_ARKOSE] = _this.setupArkose(resolve);
            var arkoseApiScript = document.createElement('script');
            arkoseApiScript.type = 'text/javascript';
            arkoseApiScript.src = ImsConstants_1.ARKOSE_JS_ENDPOINT;
            arkoseApiScript.setAttribute('data-callback', 'setupArkose');
            arkoseApiScript.addEventListener("error", function (error) {
                Log_1.default.error("Arkose script failed to load", error);
                reject(error);
            });
            document.head.append(arkoseApiScript);
        });
    };
    ArkoseInitialization.prototype.setupArkose = function (resolve) {
        return function (myArkose) {
            myArkose.setConfig({
                onCompleted: function (response) {
                    Log_1.default.info("Arkose verification completed");
                    ArkoseInitialization.arkoseInstance.setArkoseSessionToken(response.token);
                    resolve();
                },
                onReady: function () {
                    myArkose.run();
                }
            });
        };
    };
    return ArkoseInitialization;
}());
exports.ArkoseInitialization = ArkoseInitialization;
