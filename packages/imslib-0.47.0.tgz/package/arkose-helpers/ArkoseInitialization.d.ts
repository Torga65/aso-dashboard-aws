/**
 * class used to store the Arkose helper functions
 */
export declare class ArkoseInitialization {
    static arkoseInstance: any;
    arkoseSessionToken: string | null;
    static getArkoseInstance(): ArkoseInitialization;
    getArkoseSessionToken(): string | null;
    setArkoseSessionToken(sessionToken: string): void;
    /**
     * This method is used to add a script tag into the client page and load the Arkose script
     */
    callArkose(): Promise<void>;
    setupArkose(resolve: any): (myArkose: any) => void;
}
