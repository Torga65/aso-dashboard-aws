"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var IErrorType_1 = require("../adobe-id/IErrorType");
var ArkoseException = /** @class */ (function () {
    function ArkoseException(message) {
        this.message = null;
        this.errorType = IErrorType_1.IErrorType.ARKOSE_ERROR;
        this.message = message;
    }
    return ArkoseException;
}());
exports.ArkoseException = ArkoseException;
