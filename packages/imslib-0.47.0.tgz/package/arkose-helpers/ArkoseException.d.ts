import { IErrorType } from "../adobe-id/IErrorType";
export declare class ArkoseException {
    message: null;
    errorType: IErrorType;
    constructor(message: any);
}
