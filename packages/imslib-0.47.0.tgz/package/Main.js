"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var ImsInitialization_1 = __importDefault(require("./ImsInitialization"));
/**
 * Provides the possibility to an external library to create a new instance of AdobeIMS and this class is used as part of
 * the bundle process
 */
var Main = /** @class */ (function () {
    function Main() {
        ImsInitialization_1.default.initAdobeIms();
    }
    /**
   * method used only for testing in order to ensure the libray is initialized
   */
    Main.prototype.initialize = function () {
        return true;
    };
    return Main;
}());
exports.default = new Main();
