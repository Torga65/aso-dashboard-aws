/**
 * class used to pass the http errors to external applications
 */
export declare class HttpErrorResponse {
    error?: string;
    retryAfter?: number;
    message?: string;
    constructor(data: any);
}
