import { ApiResponse } from "../ims-apis/xhr/ApiResponse";
import { AdobeIdThinData } from "../adobe-id/AdobeIdThinData";
import { RideException } from "../token/RideException";
import { HttpErrorResponse } from "./HttpErrorResponse";
/**
 * class used to create a IHttpErrorResponse object in case the code is != 200
 */
declare class HttpErrorHandler {
    adobeIdThinData: AdobeIdThinData | null;
    verify(exception: ApiResponse, url?: string): HttpErrorResponse | RideException | null;
    /**
        * parse the check token response to see if there are any ride errors
        * @param refreshException represents the response from check token call
        * @param url the called url; part of the PBA Expired Idle Session workaround
        * @returns a RideException or null in case that the error code is not one from RideExceptions
        */
    parseTokenResponseForRideErrors(refreshException: any, url: string): RideException | null;
    private addRedirectUriToJump;
    /**
     * check if the exception status has the code equal 401
     * @param exception represents the exception caught during get profile method
     * @returns true if the status code is 401, otherwise false
     */
    isUnauthorizedException(exception: ApiResponse): boolean;
}
declare const _default: HttpErrorHandler;
export default _default;
