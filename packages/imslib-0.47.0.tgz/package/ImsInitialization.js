"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AdobeIMS_1 = require("./adobe-ims/AdobeIMS");
var ImsConstants_1 = require("./constants/ImsConstants");
/**
 * singleton class which is created on the same time when library is injected into the page.
 * it is used to provide the possibility to an external library to create a new instance of AdobeIMS
 * also, if the window contains a value for adobeId, it will create a new instance of AdobeIMS
 */
var ImsInitialization = /** @class */ (function () {
    function ImsInitialization() {
        /**
         *
         * @param adobeData represents the custom adobeData
         * @returns a new instance of the AdobeIms library based on input adobeIdData
         */
        this.createIMSLib = function (adobeData, adobeImsWindowKey) {
            if (adobeData === void 0) { adobeData = null; }
            if (adobeImsWindowKey === void 0) { adobeImsWindowKey = ImsConstants_1.AdobeIMSKey; }
            var adobeIMS = new AdobeIMS_1.AdobeIMS(adobeData, adobeImsWindowKey);
            window[adobeImsWindowKey] = adobeIMS;
            return adobeIMS;
        };
    }
    /**
   * create a new instance of ims lib based on adobe id data
   */
    ImsInitialization.prototype.initAdobeIms = function () {
        window[ImsConstants_1.AdobeImsFactory] = {
            createIMSLib: this.createIMSLib
        };
        var adobeIMS = window[ImsConstants_1.AdobeIMSKey] || null;
        if (!adobeIMS) {
            var adobeIdData = window[ImsConstants_1.AdobeIdKey];
            if (!adobeIdData || !adobeIdData.client_id) {
                return;
            }
            adobeIMS = this.createIMSLib(adobeIdData, ImsConstants_1.AdobeIMSKey);
            adobeIMS.initialize();
        }
    };
    return ImsInitialization;
}());
exports.default = new ImsInitialization();
