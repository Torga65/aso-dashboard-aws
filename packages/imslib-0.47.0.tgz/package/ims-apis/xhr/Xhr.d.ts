declare const _default: {
    http(options: any): Promise<any>;
    post(url: string, data: any, headers?: {}, withCredentials?: boolean | undefined, timeout?: number | undefined): Promise<any>;
    get(url: any, headers?: {}, withCredentials?: boolean | undefined, timeout?: number | undefined): Promise<any>;
};
export default _default;
