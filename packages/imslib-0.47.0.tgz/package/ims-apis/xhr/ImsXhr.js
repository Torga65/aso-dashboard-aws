"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var Debouncer_1 = __importDefault(require("../../debounce/Debouncer"));
var HttpErrorHandler_1 = __importDefault(require("../../error-handlers/HttpErrorHandler"));
var Xhr_1 = __importDefault(require("./Xhr"));
exports.default = new /** @class */ (function () {
    function ImsXhr() {
        this.triggerOnError = null;
    }
    /**
     * check if the cache contains data for the same url and parameters value;
     * if true, returns the cached value otherwise make the http call
     * @param url - url used to make a POST http request
     * @param data - dat passed to the back-end
     * @param config - http configuration
    */
    ImsXhr.prototype.post = function (url, data, config) {
        var _this = this;
        if (config === void 0) { config = {}; }
        var cachedData = Debouncer_1.default.getCachedApiResponse(url, data);
        if (cachedData) {
            var status_1 = cachedData.status, data_1 = cachedData.data;
            return status_1 === 200 ? Promise.resolve(data_1) : Promise.reject(data_1);
        }
        return Xhr_1.default.post(url, data, config)
            .then(function (response) {
            return _this.storeApiResponse(url, JSON.stringify(data), response);
        })
            .catch(function (ex) {
            return _this.verifyError(url, JSON.stringify(data), ex);
        });
    };
    /**
     * check if the cache contains data for the input url
     * if true, returns the cached value otherwise make the http call
     * @param url - url used to make a POST http request
     * @param config - contains xmlhttprequest headers
    */
    ImsXhr.prototype.get = function (url, config) {
        var _this = this;
        if (config === void 0) { config = {}; }
        var cachedData = Debouncer_1.default.getCachedApiResponse(url);
        if (cachedData) {
            var status_2 = cachedData.status, data = cachedData.data;
            return status_2 === 200 ? Promise.resolve(data) : Promise.reject(data);
        }
        return Xhr_1.default.get(url, config)
            .then(function (response) {
            return _this.storeApiResponse(url, '', response);
        })
            .catch(function (ex) {
            return _this.verifyError(url, '', ex);
        });
    };
    /**
     *
     * @param exception {ApiResponse} - represents the back-end service
     * @param url: {string} - url used to call the api
     * @param bodyParams: {string} represents the body parameters
     */
    ImsXhr.prototype.verifyError = function (url, bodyParams, exception) {
        this.storeApiResponse(url, bodyParams, exception);
        var httpErrorResponse = HttpErrorHandler_1.default.verify(exception, url);
        return Promise.reject(httpErrorResponse || exception.data);
    };
    /**
    *
    * @param response {any} - represents the back-end service
    * @param url url: {string} - url used to call the api
    * @param bodyParams {string} represents the body parameters
    */
    ImsXhr.prototype.storeApiResponse = function (url, bodyParams, response) {
        if (bodyParams === void 0) { bodyParams = ''; }
        Debouncer_1.default.storeApiResponse(url, bodyParams, response);
        return Promise.resolve(response.data);
    };
    return ImsXhr;
}());
