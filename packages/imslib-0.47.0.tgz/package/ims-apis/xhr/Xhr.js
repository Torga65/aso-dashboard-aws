"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ApiResponse_1 = require("./ApiResponse");
exports.default = new /** @class */ (function () {
    function Xhr() {
    }
    Xhr.prototype.http = function (options) {
        return new Promise(function (resolve, reject) {
            var xmlHttpObject = window.XMLHttpRequest;
            var xhr = new xmlHttpObject();
            if (typeof options.withCredentials === 'boolean') {
                xhr.withCredentials = options.withCredentials;
            }
            else {
                xhr.withCredentials = true;
            }
            if (typeof options.timeout === 'number') {
                xhr.timeout = options.timeout;
            }
            xhr.open(options.method, options.url, true);
            var addHeaders = function (headers) {
                if (!headers) {
                    return;
                }
                Object.keys(headers).forEach(function (key) {
                    xhr.setRequestHeader(key, headers[key]);
                });
            };
            xhr.onload = function onload() {
                if (this.status >= 200 && this.status < 300) {
                    return resolve(new ApiResponse_1.ApiResponse(this.status, this.response));
                }
                return reject(new ApiResponse_1.ApiResponse(this.status, this.response));
            };
            xhr.onerror = function onerror() {
                var error = new ApiResponse_1.ApiResponse(this.status, this.response);
                return reject(error);
            };
            xhr.ontimeout = function onerror() {
                var error = new ApiResponse_1.ApiResponse(0, 'timeout');
                return reject(error);
            };
            xhr.onabort = function onerror() {
                var error = new ApiResponse_1.ApiResponse(0, 'aborted');
                return reject(error);
            };
            addHeaders(options.headers);
            xhr.send(options.data);
        });
    };
    Xhr.prototype.post = function (url, data, headers, withCredentials, timeout) {
        if (headers === void 0) { headers = {}; }
        return this.http({
            headers: headers,
            method: 'POST',
            url: url,
            data: data,
            withCredentials: withCredentials,
            timeout: timeout,
        });
    };
    Xhr.prototype.get = function (url, headers, withCredentials, timeout) {
        if (headers === void 0) { headers = {}; }
        return this.http({
            headers: headers,
            method: 'GET',
            url: url,
            withCredentials: withCredentials,
            timeout: timeout,
        });
    };
    return Xhr;
}());
