import { ApiResponse } from "./ApiResponse";
declare const _default: {
    triggerOnError: Function | null;
    /**
     * check if the cache contains data for the same url and parameters value;
     * if true, returns the cached value otherwise make the http call
     * @param url - url used to make a POST http request
     * @param data - dat passed to the back-end
     * @param config - http configuration
    */
    post(url: string, data: any, config?: {}): Promise<any>;
    /**
     * check if the cache contains data for the input url
     * if true, returns the cached value otherwise make the http call
     * @param url - url used to make a POST http request
     * @param config - contains xmlhttprequest headers
    */
    get(url: any, config?: any): Promise<any>;
    /**
     *
     * @param exception {ApiResponse} - represents the back-end service
     * @param url: {string} - url used to call the api
     * @param bodyParams: {string} represents the body parameters
     */
    verifyError(url: string, bodyParams: string, exception: ApiResponse): Promise<any>;
    /**
    *
    * @param response {any} - represents the back-end service
    * @param url url: {string} - url used to call the api
    * @param bodyParams {string} represents the body parameters
    */
    storeApiResponse(url: string, bodyParams: string | undefined, response: ApiResponse): Promise<any>;
};
export default _default;
