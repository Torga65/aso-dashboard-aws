/**
 * class used to store the xhr error response
 */
export declare class ApiResponse {
    status: number;
    data: any;
    constructor(status: number, message: any);
    private toJson;
}
