export interface IAuthorizedApiRequest {
    token: string;
    client_id: string;
}
export interface IValidateTokenRequest extends IAuthorizedApiRequest {
    type?: string;
}
