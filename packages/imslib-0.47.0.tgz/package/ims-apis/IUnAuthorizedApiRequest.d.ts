export interface IUnAuthorizedApiRequest {
    client_id: string;
    scope?: string;
}
export interface ICheckTokenApiRequest extends IUnAuthorizedApiRequest {
    arkoseSessionToken?: string | null;
}
