import { IDictionary } from '../facade/IDictionary';
import { IAuthorizedApiRequest, IValidateTokenRequest } from './IAuthorizedApiRequest';
import { ICheckTokenApiRequest, IUnAuthorizedApiRequest } from './IUnAuthorizedApiRequest';
import { ITransitoryAuthorizationRequest } from '../adobe-ims/facade/ITransitoryAuthorizationRequest';
import { AuthorizationCode } from '../token/AuthorizationCode';
import { IJumpTokenRequest } from '../adobe-ims/facade/IJumpTokenRequest';
import { IJumpTokenResponse } from '../adobe-ims/facade/IJumpTokenResponse';
import { ISocialHeadlessSignInRequest, ISocialHeadlessSignInResponse } from '../adobe-ims/facade/ISocialHeadlessSignIn';
import { IJumpTokenToDeviceRequest } from '../adobe-ims/facade/IJumpTokenToDeviceRequest';
import { IJumpTokenToDeviceResponse } from '../adobe-ims/facade/IJumpTokenToDeviceResponse';
/**
 * class used as a entry point for Ims api's
 * @todo discuss rate limit --> code 429 on http response.
 */
export declare class ImsApis {
    private CONTENT_FORM_ENCODED;
    apiParameters: any;
    /**
     * imsApis constructor;
     */
    constructor(apiParameters?: any);
    /**
     * validate the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    validateToken(request: IValidateTokenRequest): Promise<any>;
    /**
     * retrieve the profile based on the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    getProfile(request: IAuthorizedApiRequest): Promise<any>;
    /**
     * @returns the user info based on the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    getUserInfo(request: IAuthorizedApiRequest): Promise<any>;
    /**
      * invalidate the input token
      * @param request IAuthorizedApiRequest contains clientId and token information
      */
    logoutToken(apiRequest: IAuthorizedApiRequest): Promise<any>;
    /**
     * Does an API to check the cookie status of the browser.
     */
    checkStatus(): Promise<any>;
    /**
     * @returns a new token
     * @param request ICheckTokenApiRequest contains clientId information
     * @param userId { string } represents the user id associated with logged user
     * @todo We will probably need also check token v5
     */
    checkToken(apiRequest: ICheckTokenApiRequest, externalParameters: IDictionary, userId: string): Promise<any>;
    /**
     * @returns a new token and profile for the existing user
     * @param request IUnAuthorizedApiRequest contains clientId information
     * @param userId contains the user id of the logged user
     * https://wiki.corp.adobe.com/display/ims/IMS+API+-+check+token#IMSAPIchecktoken-Version6
     */
    switchProfile(apiRequest: IUnAuthorizedApiRequest, externalParameters: IDictionary, userId?: string): Promise<any>;
    /**
     * @returns list of api providers
     * @param request IUnAuthorizedApiRequest contains clientId information
     */
    listSocialProviders(apiRequest: IUnAuthorizedApiRequest): Promise<any>;
    /**
    * @see {@link https://wiki.corp.adobe.com/display/ims/Implicit+Jump+Tokens |Implicit Jump Tokens}
    * @param request IUnAuthorizedApiRequest contains clientId and token information
    * @param ijt {string}
    */
    exchangeIjt(apiRequest: IUnAuthorizedApiRequest, ijt: string): Promise<any>;
    /**
     * Returns the URL to the avatar of a user
     * @param {UserId} userId
     * @returns {String}
     */
    avatarUrl(userId: string): string;
    /**
     * Makes a request to IMS to get the Floodgate release flags.
     * Optionally accepts an access token from which to decode the release flags.
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    getReleaseFlags(request: IAuthorizedApiRequest): Promise<any>;
    /**
     * Exchange the user's access_token for a Transitory Access Code (TAC) for target client and scope
     * @param tacRequest {ITransitoryAuthorizationRequest} - contains the request parameters
     * @param externalParameters {object} - contains the possible parameters used to override the api parameters
     * @param clientId {string} - the adobeid.client_id value
     */
    getTransitoryAuthorizationCode(tacRequest: ITransitoryAuthorizationRequest, externalParameters: IDictionary | undefined, clientId: string): Promise<any>;
    /**
     * returns an access token from a authorization or device code
     * @param authorizationRequest {AuthorizationCode} contains the authorization request parameters
     * @param externalParameters {object} - contains the possible parameters used to override the api parameters
     */
    getTokenFromCode(authorizationRequest: AuthorizationCode, externalParameters?: IDictionary): Promise<any>;
    /**
     * Allows a client to launch a system-browser and arrive at another IMS-integrated application
     * @see {@link https://wiki.corp.adobe.com/pages/viewpage.action?spaceKey=ims&title=IMS+API+-+jumptoken }
     * @param jumpTokenRequest {JumpTokenRequest}
     * @param externalParameters {IDictionary}
     * @returns JumpTokenResponse
     */
    jumpToken(jumpTokenRequest: IJumpTokenRequest, externalParameters: IDictionary | undefined, clientId: string): Promise<IJumpTokenResponse>;
    /**
     * Users can jump between a web browser and a mobile/desktop application and must be able to do that seamlessly
     * without entering the authorization flow in the desktop application again.
     * @see {@link https://wiki.corp.adobe.com/x/hEsEtw }
     * @param jumpTokenToDeviceRequest {IJumpTokenToDeviceRequest}
     * @param externalParameters {IDictionary}
     * @returns IJumpTokenToDeviceResponse
     */
    jumpTokenToDevice(jumpTokenToDeviceRequest: IJumpTokenToDeviceRequest, externalParameters: IDictionary | undefined, clientId: string, userId: string | null | undefined): Promise<IJumpTokenToDeviceResponse>;
    /**
       * Provides signin / signup utility via the social native headless API
       * @see {@link https://wiki.corp.adobe.com/pages/viewpage.action?pageId=1106020498 }
       * @param id_token from provider
       * @param provider_id either google, facebook or apple
       */
    socialHeadlessSignIn(socialHeadlessSignInRequest: ISocialHeadlessSignInRequest, externalParameters?: IDictionary): Promise<ISocialHeadlessSignInResponse>;
    /**
     * create the authorization header in case the accesToken exists
     * @param accessToken {string};
     * @returns {string}
     */
    private createAuthorizationHeader;
    /**
     *
     * @param headers the header which will be sent to ims server on API request
     */
    private formEncoded;
    /**
     * add clientId in header
     * @param clientId {string};
     * @param headers {IDictionary};
     */
    private addClientIdInHeader;
    private callCheckToken;
}
