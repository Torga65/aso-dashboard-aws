/**
 * singleton class which is created on the same time when library is injected into the page.
 * it is used to provide the possibility to an external library to create a new instance of AdobeIMS
 * also, if the window contains a value for adobeId, it will create a new instance of AdobeIMS
 */
declare class ImsInitialization {
    /**
   * create a new instance of ims lib based on adobe id data
   */
    initAdobeIms(): void;
    /**
     *
     * @param adobeData represents the custom adobeData
     * @returns a new instance of the AdobeIms library based on input adobeIdData
     */
    private createIMSLib;
}
declare const _default: ImsInitialization;
export default _default;
