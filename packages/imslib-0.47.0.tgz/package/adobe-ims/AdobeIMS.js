"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var CsrfService_1 = require("./csrf/CsrfService");
var Log_1 = __importDefault(require("../log/Log"));
var SignInService_1 = require("./sign-in/SignInService");
var SignInModalService_1 = require("./sign-in/SignInModalService");
var SignOutService_1 = require("./sign-out/SignOutService");
var AdobeIdData_1 = require("./../adobe-id/AdobeIdData");
var ImsApis_1 = require("./../ims-apis/ImsApis");
var IReauth_1 = require("./facade/IReauth");
var ProfileException_1 = require("../profile/ProfileException");
var ProfileService_1 = require("../profile/ProfileService");
var TokenService_1 = require("../token/TokenService");
var UrlHelper_1 = __importDefault(require("../url/UrlHelper"));
var FragmentHelper_1 = __importDefault(require("../url/FragmentHelper"));
var IErrorType_1 = require("../adobe-id/IErrorType");
var TokenExpiredException_1 = require("../token/TokenExpiredException");
var RideException_1 = require("../token/RideException");
var HttpErrorResponse_1 = require("../error-handlers/HttpErrorResponse");
var TokenAutoRefresh_1 = __importDefault(require("./token-auto-refresh/TokenAutoRefresh"));
var ImsConstants_1 = require("../constants/ImsConstants");
var Environment_1 = __importDefault(require("./environment/Environment"));
var IGrantTypes_1 = require("./facade/IGrantTypes");
var ModalSignInEvent_1 = require("../token/ModalSignInEvent");
var code_challenge_1 = require("./pkce/code-challenge");
var TokenFields_1 = require("../token/TokenFields");
var RedirectHelper_1 = require("./helpers/RedirectHelper");
var IFragmentExceptionType_1 = require("../token/IFragmentExceptionType");
var IAccountType_1 = require("./facade/IAccountType");
/**
 * Class used as a facade for ims library in order to provide public access to library functionalities
 *
 */
var AdobeIMS = /** @class */ (function () {
    /**
     * @constructor adobeData {AdobeIdData}
     * If adobeData is not null, the adobeIdData instance will be created based on these values
     *
     * if no adobeData, the imsLibrary try to read these values from window.adobeid
     *
     * After this AdobeIms class is created, it can be accessed by window[{adobeData.clientId}]
     */
    function AdobeIMS(adobeData, instanceKey) {
        var _this = this;
        if (adobeData === void 0) { adobeData = null; }
        /**
         * flag used to block the access to signin, signout functions in case the library is not fully initialized
         * { Boolean }; true if library is initialized, otherwise false
         */
        this.initialized = false;
        /**
         * The key in the window scope where the IMSLib instance is defined (if using the CDN version)
         * This key is used to prefix certain storage keys, such as the CSRF nonce
         */
        this.instanceKey = ImsConstants_1.AdobeIMSKey;
        /**
         *
         * @param authUrlRedirectResponse {String} represents the authorization redirect response
         */
        this.onPopupMessage = function (authUrlRedirectResponse) {
            if (!!authUrlRedirectResponse &&
                !!_this.adobeIdData.onModalModeSignInComplete) {
                var response = _this.tokenService.getTokenFromFragment(authUrlRedirectResponse);
                if (response instanceof TokenFields_1.TokenFields) {
                    _this.tokenService.addTokenToStorage(response);
                    if (_this.adobeIdData.onModalModeSignInComplete(response)) {
                        return Promise.resolve();
                    }
                }
            }
            UrlHelper_1.default.replaceUrl(authUrlRedirectResponse);
            return _this.initialize();
        };
        /**
         * Method used to redirect the user to signin url
         *
         * <uml>
         * start
         * :SignIn;
         * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
         * :Create the redirect url using external parameters. state object will be part of redirect url;
         * :user must enter the credentials and after that is redirected to initial uri;
         * :initialize method is used which will trigger the onAccessToken;
         * end
         * </uml>
         *
         *
         * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
         * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
         * @param grantType {IGrantTypes} represents the grant type used for sign in flow
         *
         */
        this.signIn = function (externalParameters, contextToBePassedOnRedirect, grantType) {
            if (externalParameters === void 0) { externalParameters = {}; }
            if (grantType === void 0) { grantType = IGrantTypes_1.IGrantTypes.token; }
            return __awaiter(_this, void 0, void 0, function () {
                var _a, adobeIdData, csrfService, nonce, authorizeRequestData;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            this.checkInitialized();
                            _a = this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
                            nonce = csrfService.initialize();
                            return [4 /*yield*/, adobeIdData.createRedirectRequest(externalParameters, contextToBePassedOnRedirect, nonce, grantType)];
                        case 1:
                            authorizeRequestData = _b.sent();
                            this.signInservice.signIn(authorizeRequestData);
                            return [2 /*return*/, Promise.resolve()];
                    }
                });
            });
        };
        /**
         * method used to sign in using an external token
         * @param token { String } token used for authorize; if the token is empty, the user will be redirected to the sign in screen
         * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
         * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
         */
        this.authorizeToken = function (token, externalParameters, contextToBePassedOnRedirect, grantType) {
            if (token === void 0) { token = ""; }
            if (externalParameters === void 0) { externalParameters = {}; }
            if (grantType === void 0) { grantType = IGrantTypes_1.IGrantTypes.token; }
            var _a = _this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
            var nonce = csrfService.initialize();
            return adobeIdData
                .createRedirectRequest(externalParameters, contextToBePassedOnRedirect, nonce, grantType)
                .then(function (authorizeRequestData) {
                new SignInService_1.SignInService().authorizeToken(token, authorizeRequestData);
            });
        };
        /**
         * Method used to reAuthenticate the user
         *
         * <uml>
         * start
         * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
         * :Create the redirect url using external parameters. state object will be part of redirect url;
         * :SignIn;
         * :user must enter the credentials and after that is redirected to initial uri;
         * :initialize method is used which will trigger the token and profile;
         * end
         *
         * </uml>
         *
         * @param requestedParameters object sent from outside in order to use diferent values for reAuthenticate
         * @param contextToBePassedOnRedirect {Object | undefined} represents the context which is passed during redirect
         * @param reauth {string}; represents the re authenticate value. available values are: check and force. default value is "check"
         *
         */
        this.reAuthenticate = function (requestedParameters, reauth, contextToBePassedOnRedirect, grantType) {
            if (requestedParameters === void 0) { requestedParameters = {}; }
            if (reauth === void 0) { reauth = IReauth_1.IReauth.check; }
            if (grantType === void 0) { grantType = IGrantTypes_1.IGrantTypes.token; }
            _this.checkInitialized();
            var _a = _this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
            var nonce = csrfService.initialize();
            return adobeIdData
                .createReAuthenticateRedirectRequest(requestedParameters, contextToBePassedOnRedirect, nonce, reauth, grantType)
                .then(function (authorizeRequestData) {
                _this.signInservice.signIn(authorizeRequestData);
            });
        };
        /**
         * sign in with social providers
         * @param providerName provider name used for sign in
         * @param externalParameters external parameters sent by developer
         * @param contextToBePassedOnRedirect {Object} state of the application
         */
        this.signInWithSocialProvider = function (providerName, externalParameters, contextToBePassedOnRedirect, grantType) {
            if (externalParameters === void 0) { externalParameters = {}; }
            if (grantType === void 0) { grantType = IGrantTypes_1.IGrantTypes.token; }
            _this.checkInitialized();
            if (!providerName) {
                throw new Error("please provide the provider name");
            }
            var _a = _this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
            var nonce = csrfService.initialize();
            adobeIdData
                .createSocialProviderRedirectRequest(providerName, externalParameters, contextToBePassedOnRedirect, nonce, grantType)
                .then(function (authorizeRequestData) {
                _this.signInservice.signIn(authorizeRequestData);
            });
        };
        /**
         *  Method used for sign out the user
         *
         * <uml>
         * start
         * :Signout;
         * :Create the redirect url;
         * :remove the token and profile from storage;
         * :initialize method is used which will redirect the app to initial url;
         * end
         * </uml>
         *
         * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
         *
         */
        this.signOut = function (externalParameters) {
            if (externalParameters === void 0) { externalParameters = {}; }
            _this.checkInitialized();
            _this.tokenService.purge();
            _this.profileService.removeProfile();
            var _a = _this.adobeIdData, _b = _a.api_parameters, apiParameters = _b === void 0 ? {} : _b, clientId = _a.client_id, adobeIdRedirectUri = _a.redirect_uri;
            var redirectRequest = {
                adobeIdRedirectUri: adobeIdRedirectUri,
                apiParameters: apiParameters,
                clientId: clientId,
                externalParameters: externalParameters,
            };
            var signoutBroadcastChannel = window["signoutBroadcastChannel"];
            if (signoutBroadcastChannel) {
                signoutBroadcastChannel.postMessage({
                    clientId: clientId,
                    instanceId: _this.instanceId,
                });
                signoutBroadcastChannel.close();
            }
            var signOutService = new SignOutService_1.SignOutService();
            signOutService.signOut(redirectRequest);
        };
        /**
         * Retrieve the access token that satisfies the provided PBA policy, with a validity of at least [given] millis.
         * If the current access token in Storage satisfies the policy and is valid for at least the required time,
         * it will be returned.
         *
         * Otherwise, we will call the /check/token API with the pba_policy as parameter.
         *
         * The API will either return a token, if the current user session knobs satisfy the policy, or it will return a
         * PBA ride error, with a jump url, so the user performs the required actions for the session to become compliant
         * with the policy.
         *
         *
         * @param pbaPolicy - policy identifier (name)
         * @param validAtLeastMillis - value in millis. If the current token's expiry time is sooner than this, the token will
         * be considered unusable
         * @param contextToBePassedOnRedirect - in case a PBA ride error is thrown, this will be sent on the redirect back to
         * the lib
         * @param externalParameters - any other parameters to be sent to the check/token API
         */
        this.getTokenForPBAPolicy = function (pbaPolicy, validAtLeastMillis, contextToBePassedOnRedirect, externalParameters) {
            if (pbaPolicy === void 0) { pbaPolicy = ""; }
            if (validAtLeastMillis === void 0) { validAtLeastMillis = 10000; }
            if (externalParameters === void 0) { externalParameters = {}; }
            var _a;
            var tokenInfo = _this.getAccessToken();
            // if this access token can be used, return it
            if (tokenInfo &&
                Date.now() + validAtLeastMillis < tokenInfo.expire.getTime() &&
                (!pbaPolicy || ((_a = tokenInfo.pbaSatisfiedPolicies) === null || _a === void 0 ? void 0 : _a.includes(pbaPolicy)))) {
                return Promise.resolve(tokenInfo);
            }
            // otherwise we need to call check token to obtain a new one
            var _b = _this, adobeIdData = _b.adobeIdData, csrfService = _b.csrfService;
            var nonce = csrfService.initialize();
            externalParameters.state = adobeIdData.createRedirectState(contextToBePassedOnRedirect, nonce);
            externalParameters.redirect_uri = RedirectHelper_1.RedirectHelper.createRedirectUrl(adobeIdData.redirect_uri, adobeIdData.client_id, externalParameters, "check_token", adobeIdData.scope);
            if (pbaPolicy) {
                externalParameters.pba_policy = pbaPolicy;
            }
            return _this.refreshToken(externalParameters);
        };
        /**
         * Refresh the existing token.
         *
         * <uml>
         * start
         * :refreshToken;
         * :call backend: ims/check/v4/token?client_id;
         * :read the token and profile;
         * :triggerOnAccessToken;
         * if (profile) then (yes)
         * else (nothing)
         * :call backend to get the profile ;
         * endif
         * end
         * </uml>
         *
         * @param externalParameters {Object} external parameters sent from outside of the library
         * @param autoRefresh {boolean} undocumented flag signaling that the call was made from auto-refresh context. do not set!
         * Note: if refresh token API fails, the triggerOnAccessTokenHasExpired will be triggered
         */
        this.refreshToken = function (externalParameters, autoRefresh) {
            if (externalParameters === void 0) { externalParameters = {}; }
            if (autoRefresh === void 0) { autoRefresh = false; }
            // It is possible that the client app has better user activity detection (eg. frames)
            // in which case it may call refreshToken with userInactiveSince. If that is the case,
            // TokenAutoRefresh should be updated with the new data, to be used when auto-refreshing.
            if (!autoRefresh && externalParameters.userInactiveSince) {
                var userInactiveSince = externalParameters.userInactiveSince;
                var lastUserInteraction = Date.now() - userInactiveSince * 1000;
                if (lastUserInteraction > TokenAutoRefresh_1.default.lastUserInteraction) {
                    TokenAutoRefresh_1.default.lastUserInteraction = lastUserInteraction;
                }
            }
            return _this.tokenService
                .refreshToken(externalParameters)
                .then(function (tokenResponse) {
                return _this.onTokenProfileReceived(tokenResponse);
            })
                .catch(function (ex) {
                Log_1.default.error("refresh token error", ex);
                if (ex instanceof HttpErrorResponse_1.HttpErrorResponse) {
                    return Promise.reject(ex);
                }
                var rideResult = _this.verifyRideErrorExceptionStrict(ex);
                if (rideResult) {
                    return rideResult;
                }
                _this.profileService.removeProfile();
                _this.onTokenExpired();
                return Promise.reject(ex);
            });
        };
        /**
         * retreive a new token and profile for the input user id
         * @param externalParameters {Object} external parameters sent from outside of the library
         * @param userId {String} represents the user id used to get the new token and profile
         */
        this.switchProfile = function (userId, externalParameters) {
            if (externalParameters === void 0) { externalParameters = {}; }
            if (!userId) {
                return Promise.reject(new Error("Please provide the user id for switchProfile"));
            }
            return _this.tokenService
                .switchProfile(userId, externalParameters)
                .then(function (tokenResponse) {
                return _this.onTokenProfileReceived(tokenResponse);
            })
                .catch(function (ex) { return _this.verifyRideErrorException(ex); });
        };
        this.executeErrorCallback = function (ex) {
            Log_1.default.info("initialize exception ended", ex);
            // do not invoke error callback on logout
            if (ex && ex.type === IFragmentExceptionType_1.IFragmentExceptionType.LOGOUT) {
                return;
            }
            var onError = _this.adobeIdData.onError;
            onError && onError(IErrorType_1.IErrorType.HTTP, "Initialization error");
        };
        /**
         *
         * @param instance { AdobeIMS } instance of AdobeIMS
         */
        this.triggerOnImsInstance = function (instance) {
            var evt = document.createEvent("CustomEvent");
            var evtData = {
                clientId: _this.adobeIdData.client_id,
                instance: instance,
            };
            evt.initCustomEvent(ImsConstants_1.ON_IMSLIB_INSTANCE, false, false, evtData);
            window.dispatchEvent(evt);
        };
        /**
         * process the initialize exception;
         * this method is the first method called in case there was an error during initialize flow;
         * check if the exception type is TokenExpiredException and pass the flow to the verifyCsrfException
         * @param initializeException represent the exception received during the initialize
         */
        this.processInitializeException = function (initializeException) {
            if (initializeException === void 0) { initializeException = {}; }
            Log_1.default.warn("initialize", initializeException);
            _this.restoreHash();
            return Promise.reject(initializeException);
        };
        this.verifyModalSignInEvent = function (ex) {
            if (ex instanceof ModalSignInEvent_1.ModalSignInEvent) {
                // this happens when popup window redirects and the state from fragment contains imslibmodal property as true
                return _this.notifyParentAboutModalSignIn(ex);
            }
            return Promise.reject(ex);
        };
        this.verifyTokenExpiredException = function (ex) {
            if (ex instanceof TokenExpiredException_1.TokenExpiredException) {
                _this.adobeIdData.handlers.triggerOnAccessTokenHasExpired();
                return Promise.resolve();
            }
            else {
                return Promise.reject(ex);
            }
        };
        /**
         * method called in case of exception on initialize.
         * if error is RideError, it redirects to the jump url from RideException.jump.
         * @return a rejected promise with the given ex
         */
        this.verifyRideErrorException = function (ex) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(ex instanceof RideException_1.RideException)) return [3 /*break*/, 4];
                        if (!!this.adobeIdData.overrideErrorHandler &&
                            !this.adobeIdData.overrideErrorHandler(ex)) {
                            return [2 /*return*/, Promise.reject(ex)];
                        }
                        if (!ex.isPbaExpiredIdleSessionWorkaround) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.signIn()];
                    case 1:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 2:
                        if (!ex.jump) return [3 /*break*/, 4];
                        return [4 /*yield*/, UrlHelper_1.default.replaceUrlAndWait(ex.jump, 10000)];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4: return [2 /*return*/, Promise.reject(ex)];
                }
            });
        }); };
        /**
         * Same as verifyRideErrorExceptionStrict, but returns null if ex is not RideException
         */
        this.verifyRideErrorExceptionStrict = function (ex) {
            if (!(ex instanceof RideException_1.RideException)) {
                return null;
            }
            return _this.verifyRideErrorException(ex);
        };
        /**
         * method called in case of exception on initialize.  if error type is CSRF, it calls the signOut methods
         */
        this.verifyCsrfException = function (ex) {
            var errorType = ex.type;
            if (errorType && errorType === IErrorType_1.IErrorType.CSRF) {
                _this.signOut();
            }
            return Promise.reject(ex);
        };
        /**
         * method called after a successful call to the getTokenAndProfile method in order to process the token response
         * tokenProfile: TokenProfileResponse - contains the token fields and eventually the user profile
         * @returns Promise
         */
        this.processTokenResponse = function (tokenProfile) {
            var handlers = _this.adobeIdData.handlers;
            var tokenFields = tokenProfile.tokenFields, profile = tokenProfile.profile;
            var token = tokenFields.tokenValue, state = tokenFields.state, expire = tokenFields.expire, sid = tokenFields.sid, userId = tokenFields.user_id, _a = tokenFields.other, other = _a === void 0 ? {} : _a, impersonatorId = tokenFields.impersonatorId, isImpersonatedSession = tokenFields.isImpersonatedSession, pbaSatisfiedPolicies = tokenFields.pbaSatisfiedPolicies, isGuestToken = tokenFields.isGuestToken, gse = tokenFields.gse;
            Log_1.default.info("token", token);
            if (other.from_ims) {
                UrlHelper_1.default.setHash(other.old_hash || "");
            }
            _this.profileService.removeProfileIfOtherUser(userId);
            var notificationData = {
                token: token,
                expire: expire,
                sid: sid,
                impersonatorId: impersonatorId,
                isImpersonatedSession: isImpersonatedSession,
                pbaSatisfiedPolicies: pbaSatisfiedPolicies,
                isGuestToken: isGuestToken,
                gse: gse,
            };
            tokenFields.isReauth()
                ? handlers.triggerOnReauthAccessToken(notificationData)
                : _this.tokenReceived(notificationData);
            if (profile) {
                _this.profileService.saveProfileToStorage(profile);
            }
            return Promise.resolve(state);
        };
        /**
         * method used during initialization in order to get a ijt token
         * https://wiki.corp.adobe.com/display/ims/Implicit+Jump+Tokens
         * @returns {Promise<any>} ijt response
         * @param {string} ijt value used for token excahnge (other than the one from adobeid)
         * @usage adobeIMS.adobeIdData.ijt = 'ijtValue' followed by adobeIMS.initialize()
         */
        this.exchangeIjt = function (ijt) {
            var adobeIjt = _this.adobeIdData.ijt;
            if (!ijt && !adobeIjt) {
                return Promise.reject(new Error("please set the adobeid.ijt value"));
            }
            return _this.tokenService
                .exchangeIjt(ijt || adobeIjt)
                .then(function (resp) {
                if (resp.profile) {
                    _this.profileService.saveProfileToStorage(resp.profile);
                }
                else {
                    _this.profileService.removeProfile();
                }
                return Promise.resolve(resp);
            });
        };
        this.adobeIdData = new AdobeIdData_1.AdobeIdData(adobeData);
        if (instanceKey) {
            this.instanceKey = instanceKey;
        }
        this.instanceId = "imslib-" + Math.random()
            .toString(36)
            .substring(2, 9);
        var _a = this.adobeIdData, _b = _a.api_parameters, apiParameters = _b === void 0 ? {} : _b, clientId = _a.client_id, scope = _a.scope, useLocalStorage = _a.useLocalStorage, autoValidateToken = _a.autoValidateToken, modalMode = _a.modalMode, modalSettings = _a.modalSettings;
        this.imsApis = new ImsApis_1.ImsApis(apiParameters);
        this.csrfService = new CsrfService_1.CsrfService(clientId, this.instanceKey);
        this.serviceRequest = {
            clientId: clientId,
            scope: scope,
            imsApis: this.imsApis,
        };
        this.tokenService = new TokenService_1.TokenService(__assign(__assign({}, this.serviceRequest), { useLocalStorage: useLocalStorage,
            autoValidateToken: autoValidateToken }), this.csrfService);
        this.profileService = new ProfileService_1.ProfileService(this.serviceRequest);
        this.signInservice = modalMode
            ? new SignInModalService_1.SignInModalService(this.onPopupMessage, modalSettings)
            : new SignInService_1.SignInService();
        var signoutBroadcastChannel = new BroadcastChannel("imslib-signout");
        signoutBroadcastChannel.addEventListener('message', this.onSignOutEventReceived.bind(this));
        window["signoutBroadcastChannel"] = signoutBroadcastChannel;
    }
    Object.defineProperty(AdobeIMS.prototype, "version", {
        /**
         * represents the adobe ims library version
         */
        get: function () {
            return Environment_1.default.jslibver;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AdobeIMS.prototype, "adobeid", {
        /**
         * AdobeIdData
         * the values for adobeId are read from window.adobeid or passed by using the constructor
         */
        get: function () {
            return __assign({}, this.adobeIdData);
        },
        enumerable: true,
        configurable: true
    });
    /**
     * enable the logging mechanism
     */
    AdobeIMS.prototype.enableLogging = function () {
        Log_1.default.enableLogging();
    };
    /**
     * disable the logging mechanism
     */
    AdobeIMS.prototype.disableLogging = function () {
        Log_1.default.disableLogging();
    };
    /**
     * function used to check is initialized; in case of false, an error is triggered
     */
    AdobeIMS.prototype.checkInitialized = function () {
        if (this.initialized) {
            return;
        }
        //   throw new Error( 'the imslib is not yet initialized' );
    };
    /**
     * Method used to redirect the user to the signup screen
     *
     * <uml>
     * start
     * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
     * :Create the redirect url using external parameters. state object will be part of redirect url;
     * :SignUp;
     * :initialize method is used which will trigger the token and profile;
     * end
     *
     * </uml>
     *
     * @param requestedParameters object sent from outside in order to use diferent values for signUp
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     *
     */
    AdobeIMS.prototype.signUp = function (requestedParameters, contextToBePassedOnRedirect) {
        var _this = this;
        if (requestedParameters === void 0) { requestedParameters = {}; }
        this.checkInitialized();
        var _a = this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
        if (!adobeIdData) {
            throw new Error("no adobeId on reAuthenticate");
        }
        var nonce = csrfService.initialize();
        return adobeIdData
            .createSignUpRedirectRequest(requestedParameters, contextToBePassedOnRedirect, nonce)
            .then(function (authorizeRequestData) {
            _this.signInservice.signIn(authorizeRequestData);
        });
    };
    /**
     * @function Method used to check if the user is signed in or not.
     * if local storage contains a token and is validated (only against expiration), the result is true
     * returns {boolean}
     */
    AdobeIMS.prototype.isSignedInUser = function () {
        var tokenInfo = this.getAccessToken();
        if (tokenInfo && tokenInfo.isGuestToken) {
            return false;
        }
        return tokenInfo || this.getReauthAccessToken() ? true : false;
    };
    /**
     * @function Method used to get the user profile in case the user is logged)
     * returns {IDictionary | null}  representing the user profile or null
     */
    AdobeIMS.prototype.getProfile = function () {
        var _this = this;
        var profile = this.profileService.getProfileFromStorage();
        if (profile) {
            return Promise.resolve(profile);
        }
        var tokenInfo = this.getAccessToken() || this.getReauthAccessToken();
        if (!tokenInfo) {
            var profileException = "please login before getting the profile";
            return Promise.reject(new ProfileException_1.ProfileException(profileException));
        }
        if (tokenInfo.isGuestToken) {
            var profileException = "guest account does not have a profile";
            return Promise.reject(new ProfileException_1.ProfileException(profileException));
        }
        return this.profileService
            .getProfile(tokenInfo.token)
            .then(function (profile) {
            return Promise.resolve(profile);
        })
            .catch(function (ex) {
            Log_1.default.error("get profile exception ", ex);
            if (!(ex instanceof HttpErrorResponse_1.HttpErrorResponse)) {
                return Promise.reject(new ProfileException_1.ProfileException(ex.message || ex));
            }
            return _this.refreshToken().then(function (tokenResponse) {
                return Promise.resolve(tokenResponse.profile);
            });
        });
    };
    /**
     * @function Returns the URL of the user avatar
     * @param {UserId} userId
     */
    AdobeIMS.prototype.avatarUrl = function (userId) {
        return this.imsApis.avatarUrl(userId);
    };
    /**
     * method used to retrieve the token release flags
     */
    AdobeIMS.prototype.getReleaseFlags = function (decode) {
        if (decode === void 0) { decode = false; }
        return decode
            ? this.tokenService.getDecodedReleaseFlags()
            : this.tokenService.getReleaseFlags();
    };
    /**
     *
     * Returns the access token value from the local storage
     *
     * <uml>
     * start
     * :getAccessToken;
     * :check the local storage;
     * :if token exists, it is validated against expiration;
     * :if valid the token is returned otherwise an empty token;
     * end
     * </uml>
     *
     */
    AdobeIMS.prototype.getAccessToken = function () {
        return this.getTokenFromStorage(false);
    };
    /**
     *
     * Returns the reauth access token value from the local storage
     *
     * <uml>
     * start
     * :getReauthAccessToken;
     * :check the local storage;
     * :if token exists, it is validated against expiration;
     * :if valid the token is returned otherwise an empty token;
     * end
     * </uml>
     *
     */
    AdobeIMS.prototype.getReauthAccessToken = function () {
        return this.getTokenFromStorage(true);
    };
    AdobeIMS.prototype.getTokenFromStorage = function (isReauth) {
        var tokenFields = this.tokenService.getTokenFieldsFromStorage(isReauth);
        if (!tokenFields) {
            return null;
        }
        var token = tokenFields.tokenValue, expire = tokenFields.expire, sid = tokenFields.sid, impersonatorId = tokenFields.impersonatorId, isImpersonatedSession = tokenFields.isImpersonatedSession, pbaSatisfiedPolicies = tokenFields.pbaSatisfiedPolicies, isGuestToken = tokenFields.isGuestToken, gse = tokenFields.gse;
        return {
            token: token,
            expire: expire,
            sid: sid,
            impersonatorId: impersonatorId,
            isImpersonatedSession: isImpersonatedSession,
            pbaSatisfiedPolicies: pbaSatisfiedPolicies,
            isGuestToken: isGuestToken,
            gse: gse,
        };
    };
    /**
     * method used to get the social providers.
     * returns Promise - can be used to determine when the call has been ended and read the social providers response
     */
    AdobeIMS.prototype.listSocialProviders = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var client_id = _this.adobeIdData.client_id;
            _this.imsApis
                .listSocialProviders({
                client_id: client_id,
            })
                .then(function (response) {
                resolve(response);
            })
                .catch(function (ex) {
                reject(ex);
            });
        });
    };
    /**
     *
     * @param token {string} represents the access token
     * @param expire {Date} the date when the token will expire
     */
    AdobeIMS.prototype.tokenReceived = function (tokenInfo) {
        var handlers = this.adobeIdData.handlers;
        handlers.triggerOnAccessToken(tokenInfo);
        TokenAutoRefresh_1.default.startAutoRefreshFlow({
            expire: tokenInfo.expire,
            refreshTokenMethod: this.refreshToken,
        });
    };
    /**
     * method used to process the token and profile
     * @param tokenResponse {IRefreshTokenResponse} represents the token and profile received from back-end
     */
    AdobeIMS.prototype.onTokenProfileReceived = function (tokenResponse) {
        var tokenInfo = tokenResponse.tokenInfo, profile = tokenResponse.profile;
        Log_1.default.info("token", tokenInfo);
        this.tokenReceived(tokenInfo);
        this.profileService.saveProfileToStorage(profile);
        return Promise.resolve(tokenResponse);
    };
    /**
     * @returns a promise which is resolved as true in case the token is valid otherwise false
     * validate the existing token;
     */
    AdobeIMS.prototype.validateToken = function () {
        var _this = this;
        return this.tokenService
            .validateToken()
            .then(function () {
            return Promise.resolve(true);
        })
            .catch(function (ex) {
            Log_1.default.warn("validate token exception", ex);
            if (ex instanceof HttpErrorResponse_1.HttpErrorResponse) {
                return Promise.reject(false);
            }
            _this.profileService.removeProfile();
            return Promise.reject(false);
        });
    };
    /**
     * method used in case the existent token has expired
     */
    AdobeIMS.prototype.onTokenExpired = function () {
        var handlers = this.adobeIdData.handlers;
        this.tokenService.purge();
        handlers.triggerOnAccessTokenHasExpired();
    };
    /**
     * set a new token into the local storage
     * @param tokenInfo {tokenInfo} represents the token/ expire information used by library
     */
    AdobeIMS.prototype.setStandAloneToken = function (standaloneToken) {
        return this.tokenService.setStandAloneToken(standaloneToken);
    };
    /**
     * Method called on library initialization or page reloading
     * <uml>
     * start
     * :initialize method;
     * :get token;
     * if (fragment) then (yes)
     * :returns the token from fragment;
     * else (check local storage)
     * :returns the token from local storage;
     * endif
     * :if no token: return triggerOnAccessTokenHasExpired;
     * :triggerOnAccessToken;
     * :back-end: calls getProfile ;
     * :triggerOnReady ;
     * end
     * </uml>
     *
     * Note: this method is automatically called on every page reload;
     */
    AdobeIMS.prototype.initialize = function () {
        var _this = this;
        var _a = this.adobeIdData, handlers = _a.handlers, standalone = _a.standalone, ijt = _a.ijt, alwaysRemoveTokenFromUrl = _a.alwaysRemoveTokenFromUrl, enableGuestAccounts = _a.enableGuestAccounts, enableGuestTokenForceRefresh = _a.enableGuestTokenForceRefresh, enableGuestBotDetection = _a.enableGuestBotDetection;
        var state = null;
        if (standalone) {
            this.setStandAloneToken(standalone);
        }
        var initializationMethod;
        switch (true) {
            case !!ijt:
                initializationMethod = this.exchangeIjt;
                break;
            case enableGuestAccounts:
                initializationMethod = this.tokenService.getGuestToken.bind(this.tokenService, {}, {
                    enableGuestAccounts: enableGuestAccounts,
                    enableGuestTokenForceRefresh: enableGuestTokenForceRefresh,
                    enableGuestBotDetection: enableGuestBotDetection,
                });
                break;
            default:
                initializationMethod = this.tokenService.getTokenAndProfile;
        }
        return initializationMethod()
            .then(this.processTokenResponse, this.processError.apply(this))
            .then(function (stateValue) {
            state = stateValue;
        })
            .finally(function () {
            Log_1.default.info("onReady initialization");
            window.addEventListener(ImsConstants_1.ASK_FOR_IMSLIB_INSTANCE_DOM_EVENT_NAME, function () {
                _this.triggerOnImsInstance(_this);
            }, false);
            if (alwaysRemoveTokenFromUrl) {
                UrlHelper_1.default.setHash(FragmentHelper_1.default.removeAccessToken());
            }
            handlers.triggerOnReady(state ? state.context : null);
            _this.triggerOnImsInstance(_this);
            _this.initialized = true;
        });
    };
    AdobeIMS.prototype.processError = function () {
        var _this = this;
        return function (ex) {
            return _this.verifyModalSignInEvent(ex)
                .catch(_this.processInitializeException)
                .catch(_this.verifyTokenExpiredException)
                .catch(_this.verifyRideErrorException)
                .catch(_this.verifyCsrfException)
                .catch(_this.executeErrorCallback);
        };
    };
    /**
     * pass the redirect url from the popup window to parent
     * @param modalSignInEvent {ModalSignInEvent} represents the redirect url after user has signed in
     */
    AdobeIMS.prototype.notifyParentAboutModalSignIn = function (modalSignInEvent) {
        var href = window.location.href.replace("imslibmodal", "wasmodal");
        if (window.opener) {
            window.opener.postMessage(href, window.location.origin);
            window.close();
        }
        else {
            var broadcastChannel = new BroadcastChannel("imslib");
            broadcastChannel.postMessage(href);
            broadcastChannel.close();
            window.close();
        }
        return Promise.reject("popup");
    };
    /**
     * restore the window hash value to the initial one
     */
    AdobeIMS.prototype.restoreHash = function () {
        var fragmentValues = FragmentHelper_1.default.fragmentToObject();
        if (!fragmentValues || !fragmentValues.from_ims) {
            return;
        }
        UrlHelper_1.default.setHash(fragmentValues.old_hash || "");
    };
    /**
     * Exchange the user's access_token for a Transitory Access Code (TAC) for target client and scope
     * @see {@link https://wiki.corp.adobe.com/display/ims/Transitory+Authorization+Codes |Transitory Authorization Codes}
     * @param tacRequest {ITransitoryAuthorizationRequest}
     * @param externalParameters {IDictionary} object used in order to update the default api values
     */
    AdobeIMS.prototype.getTransitoryAuthorizationCode = function (tacRequest, externalParameters) {
        if (externalParameters === void 0) { externalParameters = {}; }
        tacRequest = tacRequest || {};
        tacRequest.response_type = tacRequest.response_type || "code";
        tacRequest.target_client_id =
            tacRequest.target_client_id || this.adobeIdData.client_id;
        tacRequest.target_scope = tacRequest.target_scope || this.adobeIdData.scope;
        return this.imsApis.getTransitoryAuthorizationCode(tacRequest, externalParameters, this.adobeIdData.client_id);
    };
    /**
     * Allows a client to launch a system-browser and arrive at another IMS-integrated application
     * https://wiki.corp.adobe.com/pages/viewpage.action?spaceKey=ims&title=IMS+API+-+jumptoken
     * @param jumpTokenRequest {IJumpTokenRequest}
     * @param externalParameters {object} object used to override the default request values
     * @returns IJumpTokenResponse
     */
    AdobeIMS.prototype.jumpToken = function (jumpTokenRequest, externalParameters) {
        if (externalParameters === void 0) { externalParameters = {}; }
        jumpTokenRequest.target_client_id =
            jumpTokenRequest.target_client_id || this.adobeIdData.client_id;
        jumpTokenRequest.target_scope =
            jumpTokenRequest.target_scope || this.adobeIdData.scope;
        return this.imsApis.jumpToken(jumpTokenRequest, externalParameters, this.adobeIdData.client_id);
    };
    AdobeIMS.prototype.getVerifierByKey = function (nonce) {
        return new code_challenge_1.CodeChallenge().getVerifierByKey(nonce);
    };
    /**
     * The purpose is to sign in with a social account without navigating outside the page (i.e. via Ajax calls only)
     * @see {@link https://wiki.corp.adobe.com/pages/viewpage.action?pageId=1106020498} Social Headless API
     * @param socialHeadlessSignInRequest {ISocialHeadlessSignInRequest} containing the social provider and the token obtained
     * @param externalParameters {object} object used to override the default request values
     * @returns TokenProfileResponse with the response from the IJT exchange
     * Will initiate a signIn flow if the response is a ride error of type 'ride_AdobeID_social`
     */
    AdobeIMS.prototype.socialHeadlessSignIn = function (socialHeadlessSignInRequest, externalParameters) {
        if (externalParameters === void 0) { externalParameters = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                return [2 /*return*/, this.imsApis
                        .socialHeadlessSignIn(socialHeadlessSignInRequest, externalParameters)
                        .then(function (ijtResponse) { return _this.exchangeIjt(ijtResponse.token); })
                        .catch(function (err) {
                        if (err.error === "ride_AdobeID_social") {
                            _this.signIn({
                                idp_flow: "social.native",
                                provider_id: socialHeadlessSignInRequest.provider_id,
                                idp_token: socialHeadlessSignInRequest.idp_token,
                            });
                        }
                        return Promise.reject(err);
                    })];
            });
        });
    };
    /**
     * Returns the account type from the stored profile.
     * If the profile is not available, it will throw an error.
     *
     * For guest accounts we don't have a profile, so it will always return 'guest'.
     */
    AdobeIMS.prototype.getAccountType = function () {
        var tokenInfo = this.getAccessToken();
        if (!tokenInfo) {
            throw new Error("please login before getting the account type");
        }
        if (tokenInfo.isGuestToken) {
            return IAccountType_1.IAccountType.GUEST;
        }
        var profile = this.profileService.getProfileFromStorage();
        if (!profile) {
            throw new Error("you need to first get the profile before getting the account type");
        }
        return profile.account_type;
    };
    /**
     * Returns the guest session expiration time.
     * The format is the number of seconds from Epoch.
     */
    AdobeIMS.prototype.getSessionExpiration = function () {
        var tokenInfo = this.getAccessToken();
        if (!tokenInfo) {
            throw new Error("please obtain a token before getting the session expiration");
        }
        return tokenInfo.gse;
    };
    /**
     * Users can jump between a web browser and a mobile/desktop application and must be able to do that seamlessly
     * without entering the authorization flow in the desktop application again.
     * https://wiki.corp.adobe.com/x/hEsEtw
     * @param jumpTokenToDeviceRequest {IJumpTokenToDeviceRequest}
     * @param externalParameters {object} object used to override the default request values
     * @returns IJumpTokenToDeviceResponse
     */
    AdobeIMS.prototype.jumpTokenToDevice = function (jumpTokenToDeviceRequest, externalParameters) {
        if (externalParameters === void 0) { externalParameters = {}; }
        var tokenFields = this.tokenService.getTokenFieldsFromStorage();
        var userId = tokenFields ? tokenFields.user_id : null;
        return this.imsApis.jumpTokenToDevice(jumpTokenToDeviceRequest, externalParameters, this.adobeIdData.client_id, userId);
    };
    AdobeIMS.prototype.onSignOutEventReceived = function (event) {
        if (event.data.clientId !== this.adobeIdData.client_id ||
            event.data.instanceId === this.instanceId) {
            return;
        }
        this.tokenService.purge();
        this.profileService.removeProfile();
        if (typeof this.adobeIdData.onSignOutEventReceived === "function") {
            this.adobeIdData.onSignOutEventReceived();
        }
    };
    return AdobeIMS;
}());
exports.AdobeIMS = AdobeIMS;
