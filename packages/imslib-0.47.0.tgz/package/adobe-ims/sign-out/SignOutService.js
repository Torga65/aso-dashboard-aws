"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var RedirectHelper_1 = require("../helpers/RedirectHelper");
var UrlHelper_1 = __importDefault(require("../../url/UrlHelper"));
var Environment_1 = __importDefault(require("../environment/Environment"));
var ThirdPartyProbingService_1 = require("./ThirdPartyProbingService");
function doSignOut(redirectRequest, probingResults) {
    if (probingResults === void 0) { probingResults = undefined; }
    var apiName = 'logout';
    var apiParameters = redirectRequest.apiParameters, externalParameters = redirectRequest.externalParameters, _a = redirectRequest.adobeIdRedirectUri, adobeIdRedirectUri = _a === void 0 ? '' : _a, clientId = redirectRequest.clientId;
    var apiExternalParams = RedirectHelper_1.RedirectHelper.mergeApiParamsWithExternalParams(apiParameters, externalParameters, apiName);
    var redirectUrl = RedirectHelper_1.RedirectHelper.createDefaultRedirectUrl(adobeIdRedirectUri, clientId, apiExternalParams, apiName);
    var parameters = __assign(__assign({}, apiExternalParams), { client_id: clientId, redirect_uri: redirectUrl, jslVersion: Environment_1.default.jslibver });
    if (probingResults) {
        parameters = Object.assign(parameters, { 'probing_results': probingResults });
    }
    var queryStrings = UrlHelper_1.default.uriEncodeData(parameters);
    var url = Environment_1.default.baseUrlAdobe + "/ims/logout/v1?" + queryStrings;
    UrlHelper_1.default.replaceUrl(url);
}
/**
 * command responsible for user sign out
 */
var SignOutService = /** @class */ (function () {
    function SignOutService() {
        /**
         * @param {IRedirectRequest} redirectRequest. contains all the necessary properties necessary for sign out
         */
        this.signOut = function (redirectRequest) {
            var clientId = redirectRequest.clientId;
            // To support the Cross-Domain Session Cookies, the third party domains
            // should be probed before logging-out, so they can be included in the
            // cookie-deleting redirect chain
            if (Environment_1.default.checkTokenEndpoint.proxied) {
                new ThirdPartyProbingService_1.ThirdPartyProbingService().probe([Environment_1.default.checkTokenEndpoint.url], clientId)
                    .then(function (probingResults) {
                    doSignOut(redirectRequest, probingResults);
                })
                    // Shunt third party domains if any errors occur
                    .catch(function () {
                    doSignOut(redirectRequest);
                });
            }
            else {
                doSignOut(redirectRequest);
            }
        };
    }
    return SignOutService;
}());
exports.SignOutService = SignOutService;
