export declare class ThirdPartyProbingService {
    probe: (urls: string[], clientId: string, timeout?: number) => Promise<number[]>;
}
