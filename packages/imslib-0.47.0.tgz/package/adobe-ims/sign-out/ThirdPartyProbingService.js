"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var UrlHelper_1 = __importDefault(require("../../url/UrlHelper"));
var Xhr_1 = __importDefault(require("../../ims-apis/xhr/Xhr"));
var ThirdPartyProbingService = /** @class */ (function () {
    function ThirdPartyProbingService() {
        this.probe = function (urls, clientId, timeout) {
            if (timeout === void 0) { timeout = 2000; }
            if (!urls || urls.length === 0) {
                return Promise.resolve([]);
            }
            var headers = {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': 0,
                'X-IMS-CLIENTID': clientId
            };
            var probePath = '/ims/cdsc_probe?' + UrlHelper_1.default.uriEncodeData({ client_id: clientId });
            var results = [];
            var promises = [];
            var _loop_1 = function (i) {
                var url = urls[i] + probePath;
                promises.push(Xhr_1.default.post(url, {}, headers, false, timeout)
                    .then(function (response) { return response.status == 200 && results.push(i); })
                    .catch(function () {
                    // avoid unhandled promise warnings
                }));
            };
            for (var i = 0; i < urls.length; i++) {
                _loop_1(i);
            }
            return Promise.all(promises)
                .then(function () { return results; });
        };
    }
    return ThirdPartyProbingService;
}());
exports.ThirdPartyProbingService = ThirdPartyProbingService;
