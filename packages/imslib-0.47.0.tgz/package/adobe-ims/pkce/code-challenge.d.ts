import { ICodeChallenge } from '../../adobe-id/ICodeChallenge';
import { IDictionary } from '../../facade/IDictionary';
export declare const ONE_HOUR: number;
export declare class CodeChallenge {
    storage: Storage;
    constructor();
    b64Uri(r: any): string;
    /**
     *
     * @param nonce {String} represents the key used to store the code verifier
     * @param verifierLength {number} represents the verifier length
     * @returns {ICodeChallenge} verifier and challenge codes
     */
    createCodeChallenge(nonce: string, verifierLength?: number): Promise<ICodeChallenge>;
    /**
     *
     * @param nonce {String} represents the key used to store the code verifier
     * @param challengeAndVerifier {ICodeChallenge} represents the code challenge and code verifier
     * @returns ICodeChallenge
     */
    saveVerifierAndReturn(nonce: string, challengeAndVerifier: ICodeChallenge): Promise<ICodeChallenge>;
    /**
   * Returns the nonce values from storage as an Object or null
   * @returns {IDictionary | null}
   */
    getVerifierValuesFromStorage(): IDictionary;
    clearOlderVerifiers(verifiers: IDictionary, olderThan?: number): IDictionary;
    /**
     * rerturns the verifier from storage
     * @param key {String} represents the key used to stora the verfier
     */
    getVerifierByKey(key: string): string;
}
