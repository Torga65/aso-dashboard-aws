"use strict";
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spread = (this && this.__spread) || function () {
    for (var ar = [], i = 0; i < arguments.length; i++) ar = ar.concat(__read(arguments[i]));
    return ar;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var StorageFactory_1 = __importDefault(require("../../storage/StorageFactory"));
exports.ONE_HOUR = 60 * 60 * 3600;
var CodeChallenge = /** @class */ (function () {
    function CodeChallenge() {
        this.storage = StorageFactory_1.default.getAvailableStorage();
    }
    CodeChallenge.prototype.b64Uri = function (r) {
        return btoa(r).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    };
    /**
     *
     * @param nonce {String} represents the key used to store the code verifier
     * @param verifierLength {number} represents the verifier length
     * @returns {ICodeChallenge} verifier and challenge codes
     */
    CodeChallenge.prototype.createCodeChallenge = function (nonce, verifierLength) {
        var _this = this;
        if (verifierLength === void 0) { verifierLength = 43; }
        var cryptoObj = window['msCrypto'] || window.crypto;
        var verifier = this.b64Uri(Array.prototype.map.call(cryptoObj.getRandomValues(new Uint8Array(verifierLength)), function (r) {
            return String.fromCharCode(r);
        }).join("")).substring(0, verifierLength);
        var uintVerifierArr = new Uint8Array(verifier.length);
        for (var i = 0; i < verifier.length; i++)
            uintVerifierArr[i] = verifier.charCodeAt(i);
        var cryptoDigest = cryptoObj.subtle.digest('SHA-256', uintVerifierArr);
        return new Promise(function (resolve, reject) {
            if (window['CryptoOperation']) {
                cryptoDigest.onerror = function (err) { return reject(err); };
                cryptoDigest.oncomplete = function (response) {
                    var uintArr = new Uint8Array(response.target.result);
                    var challenge = _this.b64Uri(String.fromCharCode.apply(String, __spread(uintArr)));
                    return resolve(_this.saveVerifierAndReturn(nonce, {
                        verifier: verifier,
                        challenge: challenge,
                    }));
                };
            }
            else {
                cryptoDigest.then(function (response) {
                    var uintArr = new Uint8Array(response);
                    var challenge = _this.b64Uri(String.fromCharCode.apply(String, __spread(uintArr)));
                    return resolve(_this.saveVerifierAndReturn(nonce, {
                        verifier: verifier,
                        challenge: challenge,
                    }));
                });
            }
        });
    };
    /**
     *
     * @param nonce {String} represents the key used to store the code verifier
     * @param challengeAndVerifier {ICodeChallenge} represents the code challenge and code verifier
     * @returns ICodeChallenge
     */
    CodeChallenge.prototype.saveVerifierAndReturn = function (nonce, challengeAndVerifier) {
        var verifiers = this.getVerifierValuesFromStorage();
        var storageValue = {
            verifier: challengeAndVerifier.verifier || '',
            expiry: new Date().getTime().toString()
        };
        verifiers[nonce] = storageValue;
        this.storage.setItem('verifiers', JSON.stringify(verifiers));
        return Promise.resolve(challengeAndVerifier);
    };
    /**
   * Returns the nonce values from storage as an Object or null
   * @returns {IDictionary | null}
   */
    CodeChallenge.prototype.getVerifierValuesFromStorage = function () {
        var storageVerifiers = this.storage.getItem('verifiers');
        var verifiers = storageVerifiers ? JSON.parse(storageVerifiers) : {};
        return this.clearOlderVerifiers(verifiers);
    };
    CodeChallenge.prototype.clearOlderVerifiers = function (verifiers, olderThan) {
        if (olderThan === void 0) { olderThan = exports.ONE_HOUR; }
        var oneHourAgo = Date.now() - olderThan;
        var expiry = 0;
        Object.keys(verifiers).forEach(function (key) {
            expiry = parseInt(verifiers[key]);
            if (expiry < oneHourAgo) {
                delete verifiers[key];
            }
        });
        return verifiers;
    };
    /**
     * rerturns the verifier from storage
     * @param key {String} represents the key used to stora the verfier
     */
    CodeChallenge.prototype.getVerifierByKey = function (key) {
        var verifiers = this.getVerifierValuesFromStorage();
        var verifierObj = verifiers ? verifiers[key] : {};
        delete verifiers[key];
        this.storage.setItem('verifiers', JSON.stringify(verifiers));
        return verifierObj ? verifierObj['verifier'] : '';
    };
    return CodeChallenge;
}());
exports.CodeChallenge = CodeChallenge;
