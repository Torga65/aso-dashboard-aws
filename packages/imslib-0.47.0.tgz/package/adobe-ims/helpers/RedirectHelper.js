"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var ApiHelpers_1 = __importDefault(require("../../api-helpers/ApiHelpers"));
var ObjectUtil_1 = require("../../util/ObjectUtil");
var RedirectHelper = /** @class */ (function () {
    function RedirectHelper() {
    }
    /**
    * returns the initial redirect url; the priority value is redirect_uri from external parameters, adobeId and finally the href value from browsers
    * @param externalParameters
    * @param adobeIdRedirectUri
    */
    RedirectHelper.getInitialRedirectUri = function (externalParameters, adobeIdRedirectUri) {
        var redirectParam = externalParameters["redirect_uri"] || adobeIdRedirectUri || window.location.href;
        var redirectValue = typeof redirectParam === 'function' ? redirectParam() : redirectParam;
        var fromImsIndex = redirectValue.indexOf('from_ims');
        if (fromImsIndex === -1) {
            return redirectValue;
        }
        if (redirectValue[fromImsIndex - 1] === '#') {
            fromImsIndex--;
        }
        return redirectValue.substr(0, fromImsIndex);
    };
    /**
    * create the return url which it will be passed to authorize or logout endpoint
    * @param adobeIdRedirectUri {string} - represents the redirect_uri? set on AdobeId;
    * @param clientId {string} - represents the client id from AdobeId
    * @param externalParameters {Object} external parameters passed to library
    * @param apiName {string} api name
    *
    * @returns {string} final redirect url used for sign-in or reauth (authorize) or logout
    */
    RedirectHelper.createDefaultRedirectUrl = function (adobeIdRedirectUri, clientId, externalParameters, apiName) {
        var initialRedirectUri = this.getInitialRedirectUri(externalParameters, adobeIdRedirectUri);
        //encode the hash in case that exists
        var redirectUri = this.createOldHash(initialRedirectUri);
        return redirectUri.indexOf('?') > 0 ?
            redirectUri + "&client_id=" + clientId + "&api=" + apiName :
            redirectUri + "?client_id=" + clientId + "&api=" + apiName;
    };
    /**
     * <uml>
     * start
     * :CreateDefaultRedirectUrl ;
     * :merge api parameters with external parameters
     * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
     * end
     * </uml>
     *
     * create the return url which it will be passed to authorization endpoint
     * @param redirectUri {string} - represents the base url href value
     * @param clientId {string} - represents the client id
     * @param externalParameters {Object} external parameters passed to library
     * @param apiName {string} api name
     * @parm scope {string} scope of sign in
     * @returns {string} final redirect url used for sign in
     */
    RedirectHelper.createRedirectUrl = function (adobeIdRedirectUri, clientId, externalParameters, apiName, scope) {
        if (scope === void 0) { scope = ''; }
        var redirectUri = this.createDefaultRedirectUrl(adobeIdRedirectUri, clientId, externalParameters, apiName);
        scope = scope || externalParameters["scope"] || '';
        if (scope) {
            redirectUri = redirectUri + "&scope=" + scope;
        }
        var reauth = externalParameters["reauth"] || '';
        if (reauth) {
            redirectUri = redirectUri + "&reauth=" + reauth;
        }
        return redirectUri;
    };
    /**
     * @param source {string} represent the url value
     * @returns {string} the url with hash
     */
    RedirectHelper.createOldHash = function (source) {
        var index = source.indexOf("#");
        if (index < 0) {
            return source + "#old_hash=&from_ims=true";
        }
        var baseUrl = source.substring(0, index);
        var hash = source.substring(index + 1);
        return baseUrl + "#old_hash=" + hash + "&from_ims=true";
    };
    RedirectHelper.mergeApiParamsWithExternalParams = function (apiParameters, externalParameters, apiName) {
        return ObjectUtil_1.merge(ApiHelpers_1.default.getCustomApiParameters(apiParameters, apiName), externalParameters);
    };
    return RedirectHelper;
}());
exports.RedirectHelper = RedirectHelper;
