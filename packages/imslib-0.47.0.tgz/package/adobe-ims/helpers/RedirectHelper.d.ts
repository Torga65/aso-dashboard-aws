import { IDictionary } from "../../facade/IDictionary";
export declare class RedirectHelper {
    /**
    * returns the initial redirect url; the priority value is redirect_uri from external parameters, adobeId and finally the href value from browsers
    * @param externalParameters
    * @param adobeIdRedirectUri
    */
    static getInitialRedirectUri(externalParameters: IDictionary, adobeIdRedirectUri: string | (() => string) | undefined): string;
    /**
    * create the return url which it will be passed to authorize or logout endpoint
    * @param adobeIdRedirectUri {string} - represents the redirect_uri? set on AdobeId;
    * @param clientId {string} - represents the client id from AdobeId
    * @param externalParameters {Object} external parameters passed to library
    * @param apiName {string} api name
    *
    * @returns {string} final redirect url used for sign-in or reauth (authorize) or logout
    */
    static createDefaultRedirectUrl(adobeIdRedirectUri: string | (() => string), clientId: string, externalParameters: IDictionary, apiName: string): string;
    /**
     * <uml>
     * start
     * :CreateDefaultRedirectUrl ;
     * :merge api parameters with external parameters
     * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
     * end
     * </uml>
     *
     * create the return url which it will be passed to authorization endpoint
     * @param redirectUri {string} - represents the base url href value
     * @param clientId {string} - represents the client id
     * @param externalParameters {Object} external parameters passed to library
     * @param apiName {string} api name
     * @parm scope {string} scope of sign in
     * @returns {string} final redirect url used for sign in
     */
    static createRedirectUrl(adobeIdRedirectUri: string | (() => string), clientId: string, externalParameters: IDictionary, apiName: string, scope?: string): string;
    /**
     * @param source {string} represent the url value
     * @returns {string} the url with hash
     */
    static createOldHash(source: string): string;
    static mergeApiParamsWithExternalParams(apiParameters: IDictionary, externalParameters: IDictionary, apiName: string): IDictionary;
}
