export declare class CheckTokenEndpoint {
    private static THIRD_PARTY_DOMAINS_PROD;
    private static THIRD_PARTY_DOMAINS_STAGE;
    static computeEndpoint(useProxy: boolean, hostname: string, isStage: boolean, servicesUrl: string): CheckTokenEndpoint;
    proxied: boolean;
    url: string;
    fallbackUrl: string;
    constructor(proxied?: boolean, url?: string, fallbackUrl?: string);
    shouldFallbackToAdobe(e: any): boolean;
}
