import { IEnvironment } from "../../adobe-id/IEnvironment";
import { CheckTokenEndpoint } from "./CheckTokenEndpoint";
/**
 * class used to store the variables used for ims flow
 */
declare class Environment {
    /**
     * @property {String} Represents the base url used on api (back-end) call in case of getProfile, getUserInfo and validateToken;
     */
    baseUrlAdobe: string;
    /**
     * @property {string} Represents the base url used on api (back-end) call in case of logoutToken, checkStatus, listSocialProviders and exchangeIjt;
     */
    baseUrlServices: string;
    /**
     * @property {object} Represents the base url used on api (back-end) call in case of checkToken;
     */
    checkTokenEndpoint: CheckTokenEndpoint;
    /**
     * @property {string} this parameter is passed to redirect uri during a sign in or sign out operation
     */
    jslibver: string;
    loadEnvironment(environment: IEnvironment, useProxy?: boolean, hostname?: string): void;
}
declare const _default: Environment;
export default _default;
