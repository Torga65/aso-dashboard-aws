/**
 * Represents the type of account.
 */
export declare enum IAccountType {
    /**
     * Represents the type of account as personal.
     */
    TYPE1 = "type1",
    /**
     * Represents the type of account as federated.
     */
    TYPE3 = "type3",
    /**
     * Represents the type of account as T2E.
     */
    TYPE2E = "type2e",
    /**
     * Represents the type of account as guest.
     */
    GUEST = "guest"
}
