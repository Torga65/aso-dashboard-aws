/**
 * interface used to store the jumptoken/v2 api response
 *
 */
export interface IJumpTokenToDeviceResponse {
    /**
     * The URI for the jump token consumption.
     * example: "jumpUrl":"https://ims-na1.adobelogin.com/ims/jump/v2/eyJraWQiOiJLMjAxNiIsIm...jocyrzk2LHUQ",
     */
    jumpUrl: string;
    /**
     * Timestamp, in milliseconds, when the jump URL will be considered invalid.
     */
    expiresAt: number;
    /**
     * Optional. 4-digit number. Nullable. IMS will return a response without a code if the user is a Federated user (Type 3) or the user has MFA enabled
     */
    code?: string;
}
