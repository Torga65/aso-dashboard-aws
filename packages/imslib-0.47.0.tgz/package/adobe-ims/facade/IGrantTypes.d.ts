/**
 * Enumeration values used for available grant types
 *
 * Default value is token
 */
export declare enum IGrantTypes {
    /**
     * token
     */
    token = "token",
    /**
     * authorization code
     */
    code = "code"
}
