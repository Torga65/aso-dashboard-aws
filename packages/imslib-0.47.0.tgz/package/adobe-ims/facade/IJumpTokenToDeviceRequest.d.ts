/**
 * model used for jumptoken/v2 method
 *
 */
export interface IJumpTokenToDeviceRequest {
    /**
     * The ID of the target client group. See Client Groups .
     * Any client from the target client group will be able to consume the generated jump token.
     */
    target_client_group: string;
    /**
     * Optional. The URL to which to direct the user's browser on completion of the operation
     */
    client_redirect?: string;
}
