"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var JumpTargetResponseType;
(function (JumpTargetResponseType) {
    JumpTargetResponseType["code"] = "code";
    JumpTargetResponseType["token"] = "token";
    JumpTargetResponseType["device"] = "device";
})(JumpTargetResponseType || (JumpTargetResponseType = {}));
