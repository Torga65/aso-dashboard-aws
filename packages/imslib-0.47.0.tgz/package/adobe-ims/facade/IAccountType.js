"use strict";
/**
 * Represents the type of account.
 */
Object.defineProperty(exports, "__esModule", { value: true });
var IAccountType;
(function (IAccountType) {
    /**
     * Represents the type of account as personal.
     */
    IAccountType["TYPE1"] = "type1";
    /**
     * Represents the type of account as federated.
     */
    IAccountType["TYPE3"] = "type3";
    /**
     * Represents the type of account as T2E.
     */
    IAccountType["TYPE2E"] = "type2e";
    /**
     * Represents the type of account as guest.
     */
    IAccountType["GUEST"] = "guest";
})(IAccountType = exports.IAccountType || (exports.IAccountType = {}));
