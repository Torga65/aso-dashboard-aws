"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var UrlHelper_1 = __importDefault(require("../../url/UrlHelper"));
var Environment_1 = __importDefault(require("../environment/Environment"));
var BaseSignInService_1 = require("./BaseSignInService");
/**
 * command responsable for user sign in
 */
var SignInService = /** @class */ (function (_super) {
    __extends(SignInService, _super);
    function SignInService() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**
         * execute the sign in method which redirects the user to the login page
         * <uml>
         * start
         * :CreateRedirectUrl;
         * :merge api parameters with external parameters
         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
         * end
         * </uml>
         *
         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
         */
        _this.signIn = function (redirectRequest) {
            var url = _this.createRedirectUrl(redirectRequest);
            UrlHelper_1.default.setHrefUrl(url);
        };
        /**
         *
         * @param token { String } value used to authorize a user based on this token value
         * @param redirectRequest { IRedirectRequest } contains the object properties which are passed to the authorize api
         */
        _this.authorizeToken = function (token, redirectRequest) {
            var parameters = _this.composeRedirectUrl(redirectRequest);
            if (token) {
                parameters.user_assertion = token;
                parameters.user_assertion_type = 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer';
            }
            var postForm = _this.createAuthorizeForm(parameters);
            postForm.submit();
        };
        return _this;
    }
    /**
     * returns a html form containing all the properties from the parameter object
     * @param parameters {object} contains the properties which will be passed to authorize api (as form submit post action)
     */
    SignInService.prototype.createAuthorizeForm = function (parameters) {
        var formAction = Environment_1.default.baseUrlAdobe + "/ims/authorize/v1";
        var form = document.createElement("form");
        form.style.display = "none";
        form.setAttribute("method", "post");
        form.setAttribute("action", formAction);
        var formEl = null;
        var paramValue = null;
        var paramValueAsString = '';
        for (var propertyName in parameters) {
            paramValue = parameters[propertyName];
            if (typeof paramValue === 'object') {
                if (Object.keys(paramValue).length === 0) {
                    continue;
                }
                paramValueAsString = JSON.stringify(paramValue);
            }
            else {
                paramValueAsString = paramValue;
            }
            if (paramValueAsString !== '') {
                formEl = this.createFormElement('input', 'text', propertyName, paramValueAsString);
                form.appendChild(formEl);
            }
        }
        document.getElementsByTagName("body")[0]
            .appendChild(form);
        return form;
    };
    /**
     * create a new html form element; this element will be added to the form
     * @param inputType {String} input html element type
     * @param type {String} type of the input element
     * @param name {String} name of the input element
     * @param value {String} value for the element
     */
    SignInService.prototype.createFormElement = function (inputType, type, name, value) {
        var formElement = document.createElement(inputType);
        formElement.setAttribute("type", type);
        formElement.setAttribute("name", name);
        formElement.setAttribute("value", value);
        return formElement;
    };
    return SignInService;
}(BaseSignInService_1.BaseSignInService));
exports.SignInService = SignInService;
