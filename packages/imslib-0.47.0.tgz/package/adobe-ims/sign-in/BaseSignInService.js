"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var UrlHelper_1 = __importDefault(require("../../url/UrlHelper"));
var Environment_1 = __importDefault(require("../environment/Environment"));
var RedirectHelper_1 = require("../helpers/RedirectHelper");
var ObjectUtil_1 = require("../../util/ObjectUtil");
/**
 * command responsable for user sign in
 */
var BaseSignInService = /** @class */ (function () {
    function BaseSignInService() {
        var _this = this;
        /**
         * execute the sign in method which redirects the user to the login page
         * <uml>
         * start
         * :CreateRedirectUrl;
         * :merge api parameters with external parameters
         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
         * end
         * </uml>
         *
         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
         */
        this.composeRedirectUrl = function (redirectRequest) {
            var apiName = "authorize";
            var apiParameters = redirectRequest.apiParameters, _a = redirectRequest.externalParameters, externalParameters = _a === void 0 ? {} : _a, _b = redirectRequest.adobeIdRedirectUri, adobeIdRedirectUri = _b === void 0 ? "" : _b, clientId = redirectRequest.clientId, localeAdobeId = redirectRequest.locale, _c = redirectRequest.state, state = _c === void 0 ? {} : _c;
            var _d = redirectRequest.scope, scope = _d === void 0 ? externalParameters["scope"] || apiParameters["scope"] || "" : _d;
            var apiExternalParams = RedirectHelper_1.RedirectHelper.mergeApiParamsWithExternalParams(apiParameters, externalParameters, apiName);
            if (state) {
                apiExternalParams.state = ObjectUtil_1.merge(apiExternalParams.state || {}, state);
            }
            var redirectUrl = RedirectHelper_1.RedirectHelper.createRedirectUrl(adobeIdRedirectUri, clientId, apiExternalParams, apiName, scope);
            var locale = externalParameters.locale || localeAdobeId || '';
            var 
            // eslint-disable-next-line @typescript-eslint/camelcase
            _e = redirectRequest.response_type, 
            // eslint-disable-next-line @typescript-eslint/camelcase
            response_type = _e === void 0 ? apiExternalParams["response_type"] || '' : _e;
            var parameters = __assign(__assign({}, apiExternalParams), { client_id: clientId, scope: scope,
                locale: locale,
                response_type: response_type, jslVersion: Environment_1.default.jslibver, redirect_uri: redirectUrl });
            return parameters;
        };
        /**
         * execute the sign in method which redirects the user to the login page
         * <uml>
         * start
         * :CreateRedirectUrl;
         * :merge api parameters with external parameters
         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
         * end
         * </uml>
         *
         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
         */
        this.createRedirectUrl = function (redirectRequest) {
            var parameters = _this.composeRedirectUrl(redirectRequest);
            var queryStrings = UrlHelper_1.default.uriEncodeData(parameters);
            var url = Environment_1.default.baseUrlAdobe + "/ims/authorize/v1?" + queryStrings;
            return url;
        };
    }
    return BaseSignInService;
}());
exports.BaseSignInService = BaseSignInService;
