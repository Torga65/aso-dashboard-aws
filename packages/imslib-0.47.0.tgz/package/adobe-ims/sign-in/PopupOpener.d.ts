import { PopupSettings } from "./PopupSettings";
/**
 * class used to open a new authorization popup
 */
declare class PopupOpener {
    /**
     * refernce of the window object
     */
    private windowObjectReference;
    /**
     * represents the previous url used to open the popup window
     */
    private previousUrl;
    /**
     * hook function used to pipe the received data from the parent popup the the AdobeIMS instance context
     */
    private onProcessLocation;
    /**
     * timer handler used to read the href from popup window;
     * note: it is used only in case the parent.opener is undefined; edge bug!
     */
    private timerId;
    /**
     * optional property that can be set when opening the popup in order to allow an origin other than
     * the default auth.services.adobe.com
     */
    private allowOrigin?;
    private broadcastChannel?;
    /**
     * open the popup window used for authorization
     * @param url {String} url of the popup window
     * @param popupSettings {object} contains the popup setting as height and width
     * @param onPopupMessage {Function} function used to transfer the data from popup
     */
    openSignInWindow: (url: string, popupHaspProp: string, popupSettings: PopupSettings, onPopupMessage: Function) => void;
    /**
     * function used to receive the message from the popup window
     * @param event {window event} contains the dom event passed by popup window
     */
    receiveMessage: (event: any) => void;
}
declare const _default: PopupOpener;
export default _default;
