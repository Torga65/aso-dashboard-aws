/**
 * class used to store the modal settings
 */
export declare class PopupSettings {
    title: string;
    allowOrigin?: string;
    width: number;
    height: 700;
    top: number;
    left: number;
    constructor(data?: any);
}
