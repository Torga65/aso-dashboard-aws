import { IRedirectRequest } from "../facade/IRedirectRequest";
/**
 * command responsable for user sign in
 */
export declare class BaseSignInService {
    /**
     * execute the sign in method which redirects the user to the login page
     * <uml>
     * start
     * :CreateRedirectUrl;
     * :merge api parameters with external parameters
     * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
     * end
     * </uml>
     *
     * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
     */
    composeRedirectUrl: (redirectRequest: IRedirectRequest) => any;
    /**
     * execute the sign in method which redirects the user to the login page
     * <uml>
     * start
     * :CreateRedirectUrl;
     * :merge api parameters with external parameters
     * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
     * end
     * </uml>
     *
     * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
     */
    createRedirectUrl: (redirectRequest: IRedirectRequest) => string;
}
