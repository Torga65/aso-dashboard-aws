"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var PopupOpener_1 = __importDefault(require("./PopupOpener"));
var BaseSignInService_1 = require("./BaseSignInService");
/**
 * command responsable for user sign in
 */
var SignInModalService = /** @class */ (function (_super) {
    __extends(SignInModalService, _super);
    /**
     * constructor of the SignInModalService
     */
    function SignInModalService(onPopupMessage, popupSettings) {
        var _this = _super.call(this) || this;
        /**
         * execute the sign in method which redirects the user to the login page
         * <uml>
         * start
         * :CreateRedirectUrl;
         * :merge api parameters with external parameters
         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
         * end
         * </uml>
         *
         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
         * @param onPopupMessage {Function} represents the function used, as a hook, to be triggered when a message comes from popup
         */
        _this.signIn = function (redirectRequest) {
            redirectRequest.state = __assign(__assign({}, redirectRequest.state), { imslibmodal: true });
            var nonce = redirectRequest.state.nonce;
            var url = _this.createRedirectUrl(redirectRequest);
            PopupOpener_1.default.openSignInWindow(url, nonce, _this.popupSettings, _this.onPopupMessage);
        };
        _this.onPopupMessage = onPopupMessage;
        _this.popupSettings = popupSettings;
        return _this;
    }
    return SignInModalService;
}(BaseSignInService_1.BaseSignInService));
exports.SignInModalService = SignInModalService;
