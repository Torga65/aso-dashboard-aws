import { IRedirectRequest } from "../facade/IRedirectRequest";
import { BaseSignInService } from "./BaseSignInService";
import { PopupSettings } from './PopupSettings';
import { ISignInService } from './ISignInService';
/**
 * command responsable for user sign in
 */
export declare class SignInModalService extends BaseSignInService implements ISignInService {
    /**
     * function used to be triggered from the popup window
     */
    onPopupMessage: Function;
    /**
     * represents the popup settings
     */
    popupSettings: PopupSettings;
    /**
     * constructor of the SignInModalService
     */
    constructor(onPopupMessage: Function, popupSettings: PopupSettings);
    /**
     * execute the sign in method which redirects the user to the login page
     * <uml>
     * start
     * :CreateRedirectUrl;
     * :merge api parameters with external parameters
     * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
     * end
     * </uml>
     *
     * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
     * @param onPopupMessage {Function} represents the function used, as a hook, to be triggered when a message comes from popup
     */
    signIn: (redirectRequest: IRedirectRequest) => void;
}
