import { IAdobeIdData } from "../adobe-id/IAdobeIdData";
import { IDictionary } from "./../facade/IDictionary";
import { ImsApis } from "./../ims-apis/ImsApis";
import { IReauth } from "./facade/IReauth";
import { TokenService } from "../token/TokenService";
import { TokenProfileResponse } from "./TokenProfileResponse";
import { StandaloneToken } from "../token/StandaloneToken";
import { IAdobeIMS } from "./facade/IAdobeIMS";
import { ITokenInformation } from "../adobe-id/custom-types/CustomTypes";
import { ITransitoryAuthorizationRequest } from "./facade/ITransitoryAuthorizationRequest";
import { ITransitoryAuthorizationResponse } from "./facade/ITransitoryAuthorizationResponse";
import { IGrantTypes } from "./facade/IGrantTypes";
import { IJumpTokenRequest } from "./facade/IJumpTokenRequest";
import { IJumpTokenResponse } from "./facade/IJumpTokenResponse";
import { ISocialHeadlessSignInRequest } from "./facade/ISocialHeadlessSignIn";
import { IJumpTokenToDeviceRequest } from "./facade/IJumpTokenToDeviceRequest";
import { IJumpTokenToDeviceResponse } from "./facade/IJumpTokenToDeviceResponse";
/**
 * Class used as a facade for ims library in order to provide public access to library functionalities
 *
 */
export declare class AdobeIMS implements IAdobeIMS {
    /**
     * AdobeIdData
     * the values for adobeId are read from window.adobeid or passed by using the constructor
     */
    private adobeIdData;
    /**
     * Token Service instance used for token management
     */
    tokenService: TokenService;
    /**
     * Profile service instance used for profile management
     */
    private profileService;
    /**
     * Service Request object used for token and profile services.
     * contains the clientId, scope and imsApis instance
     */
    private serviceRequest;
    /**
     * instance of CsrfService
     */
    private csrfService;
    private signInservice;
    /**
     * Represents the class used to call the back-end methods;
     * it is visible ONLY because this is the only way t mock the api calls during functional tests
     */
    imsApis: ImsApis;
    /**
     * represents the adobe ims library version
     */
    get version(): string;
    /**
     * flag used to block the access to signin, signout functions in case the library is not fully initialized
     * { Boolean }; true if library is initialized, otherwise false
     */
    private initialized;
    /**
     * The key in the window scope where the IMSLib instance is defined (if using the CDN version)
     * This key is used to prefix certain storage keys, such as the CSRF nonce
     */
    private instanceKey;
    /**
     * AdobeIdData
     * the values for adobeId are read from window.adobeid or passed by using the constructor
     */
    get adobeid(): IAdobeIdData;
    private instanceId;
    /**
     * @constructor adobeData {AdobeIdData}
     * If adobeData is not null, the adobeIdData instance will be created based on these values
     *
     * if no adobeData, the imsLibrary try to read these values from window.adobeid
     *
     * After this AdobeIms class is created, it can be accessed by window[{adobeData.clientId}]
     */
    constructor(adobeData?: IAdobeIdData | null, instanceKey?: string);
    /**
     * enable the logging mechanism
     */
    enableLogging(): void;
    /**
     * disable the logging mechanism
     */
    disableLogging(): void;
    /**
     * function used to check is initialized; in case of false, an error is triggered
     */
    private checkInitialized;
    /**
     *
     * @param authUrlRedirectResponse {String} represents the authorization redirect response
     */
    onPopupMessage: (authUrlRedirectResponse: string) => Promise<any>;
    /**
     * Method used to redirect the user to signin url
     *
     * <uml>
     * start
     * :SignIn;
     * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
     * :Create the redirect url using external parameters. state object will be part of redirect url;
     * :user must enter the credentials and after that is redirected to initial uri;
     * :initialize method is used which will trigger the onAccessToken;
     * end
     * </uml>
     *
     *
     * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     * @param grantType {IGrantTypes} represents the grant type used for sign in flow
     *
     */
    signIn: (externalParameters?: IDictionary, contextToBePassedOnRedirect?: any, grantType?: IGrantTypes) => Promise<void>;
    /**
     * method used to sign in using an external token
     * @param token { String } token used for authorize; if the token is empty, the user will be redirected to the sign in screen
     * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     */
    authorizeToken: (token?: string, externalParameters?: IDictionary, contextToBePassedOnRedirect?: any, grantType?: IGrantTypes) => Promise<void>;
    /**
     * Method used to reAuthenticate the user
     *
     * <uml>
     * start
     * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
     * :Create the redirect url using external parameters. state object will be part of redirect url;
     * :SignIn;
     * :user must enter the credentials and after that is redirected to initial uri;
     * :initialize method is used which will trigger the token and profile;
     * end
     *
     * </uml>
     *
     * @param requestedParameters object sent from outside in order to use diferent values for reAuthenticate
     * @param contextToBePassedOnRedirect {Object | undefined} represents the context which is passed during redirect
     * @param reauth {string}; represents the re authenticate value. available values are: check and force. default value is "check"
     *
     */
    reAuthenticate: (requestedParameters?: IDictionary, reauth?: IReauth, contextToBePassedOnRedirect?: any, grantType?: IGrantTypes) => Promise<void>;
    /**
     * Method used to redirect the user to the signup screen
     *
     * <uml>
     * start
     * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
     * :Create the redirect url using external parameters. state object will be part of redirect url;
     * :SignUp;
     * :initialize method is used which will trigger the token and profile;
     * end
     *
     * </uml>
     *
     * @param requestedParameters object sent from outside in order to use diferent values for signUp
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     *
     */
    signUp(requestedParameters?: IDictionary, contextToBePassedOnRedirect?: any): Promise<void>;
    /**
     * sign in with social providers
     * @param providerName provider name used for sign in
     * @param externalParameters external parameters sent by developer
     * @param contextToBePassedOnRedirect {Object} state of the application
     */
    signInWithSocialProvider: (providerName: any, externalParameters?: IDictionary, contextToBePassedOnRedirect?: any, grantType?: IGrantTypes) => void;
    /**
     * @function Method used to check if the user is signed in or not.
     * if local storage contains a token and is validated (only against expiration), the result is true
     * returns {boolean}
     */
    isSignedInUser(): boolean;
    /**
     * @function Method used to get the user profile in case the user is logged)
     * returns {IDictionary | null}  representing the user profile or null
     */
    getProfile(): Promise<any>;
    /**
     *  Method used for sign out the user
     *
     * <uml>
     * start
     * :Signout;
     * :Create the redirect url;
     * :remove the token and profile from storage;
     * :initialize method is used which will redirect the app to initial url;
     * end
     * </uml>
     *
     * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
     *
     */
    signOut: (externalParameters?: IDictionary) => void;
    /**
     * @function Returns the URL of the user avatar
     * @param {UserId} userId
     */
    avatarUrl(userId: string): string;
    /**
     * method used to retrieve the token release flags
     */
    getReleaseFlags(decode?: boolean): Promise<any>;
    /**
     *
     * Returns the access token value from the local storage
     *
     * <uml>
     * start
     * :getAccessToken;
     * :check the local storage;
     * :if token exists, it is validated against expiration;
     * :if valid the token is returned otherwise an empty token;
     * end
     * </uml>
     *
     */
    getAccessToken(): ITokenInformation | null;
    /**
     *
     * Returns the reauth access token value from the local storage
     *
     * <uml>
     * start
     * :getReauthAccessToken;
     * :check the local storage;
     * :if token exists, it is validated against expiration;
     * :if valid the token is returned otherwise an empty token;
     * end
     * </uml>
     *
     */
    getReauthAccessToken(): ITokenInformation | null;
    private getTokenFromStorage;
    /**
     * method used to get the social providers.
     * returns Promise - can be used to determine when the call has been ended and read the social providers response
     */
    listSocialProviders(): Promise<any>;
    /**
     *
     * @param token {string} represents the access token
     * @param expire {Date} the date when the token will expire
     */
    private tokenReceived;
    /**
     * Retrieve the access token that satisfies the provided PBA policy, with a validity of at least [given] millis.
     * If the current access token in Storage satisfies the policy and is valid for at least the required time,
     * it will be returned.
     *
     * Otherwise, we will call the /check/token API with the pba_policy as parameter.
     *
     * The API will either return a token, if the current user session knobs satisfy the policy, or it will return a
     * PBA ride error, with a jump url, so the user performs the required actions for the session to become compliant
     * with the policy.
     *
     *
     * @param pbaPolicy - policy identifier (name)
     * @param validAtLeastMillis - value in millis. If the current token's expiry time is sooner than this, the token will
     * be considered unusable
     * @param contextToBePassedOnRedirect - in case a PBA ride error is thrown, this will be sent on the redirect back to
     * the lib
     * @param externalParameters - any other parameters to be sent to the check/token API
     */
    getTokenForPBAPolicy: (pbaPolicy?: string, validAtLeastMillis?: number, contextToBePassedOnRedirect?: any, externalParameters?: IDictionary) => Promise<any>;
    /**
     * Refresh the existing token.
     *
     * <uml>
     * start
     * :refreshToken;
     * :call backend: ims/check/v4/token?client_id;
     * :read the token and profile;
     * :triggerOnAccessToken;
     * if (profile) then (yes)
     * else (nothing)
     * :call backend to get the profile ;
     * endif
     * end
     * </uml>
     *
     * @param externalParameters {Object} external parameters sent from outside of the library
     * @param autoRefresh {boolean} undocumented flag signaling that the call was made from auto-refresh context. do not set!
     * Note: if refresh token API fails, the triggerOnAccessTokenHasExpired will be triggered
     */
    refreshToken: (externalParameters?: IDictionary, autoRefresh?: boolean) => Promise<any>;
    /**
     * retreive a new token and profile for the input user id
     * @param externalParameters {Object} external parameters sent from outside of the library
     * @param userId {String} represents the user id used to get the new token and profile
     */
    switchProfile: (userId: string, externalParameters?: IDictionary) => Promise<any>;
    /**
     * method used to process the token and profile
     * @param tokenResponse {IRefreshTokenResponse} represents the token and profile received from back-end
     */
    private onTokenProfileReceived;
    /**
     * @returns a promise which is resolved as true in case the token is valid otherwise false
     * validate the existing token;
     */
    validateToken(): Promise<boolean>;
    /**
     * method used in case the existent token has expired
     */
    private onTokenExpired;
    /**
     * set a new token into the local storage
     * @param tokenInfo {tokenInfo} represents the token/ expire information used by library
     */
    setStandAloneToken(standaloneToken: StandaloneToken): boolean;
    /**
     * Method called on library initialization or page reloading
     * <uml>
     * start
     * :initialize method;
     * :get token;
     * if (fragment) then (yes)
     * :returns the token from fragment;
     * else (check local storage)
     * :returns the token from local storage;
     * endif
     * :if no token: return triggerOnAccessTokenHasExpired;
     * :triggerOnAccessToken;
     * :back-end: calls getProfile ;
     * :triggerOnReady ;
     * end
     * </uml>
     *
     * Note: this method is automatically called on every page reload;
     */
    initialize(): Promise<any>;
    private processError;
    private executeErrorCallback;
    /**
     *
     * @param instance { AdobeIMS } instance of AdobeIMS
     */
    private triggerOnImsInstance;
    /**
     * process the initialize exception;
     * this method is the first method called in case there was an error during initialize flow;
     * check if the exception type is TokenExpiredException and pass the flow to the verifyCsrfException
     * @param initializeException represent the exception received during the initialize
     */
    private processInitializeException;
    private verifyModalSignInEvent;
    private verifyTokenExpiredException;
    /**
     * pass the redirect url from the popup window to parent
     * @param modalSignInEvent {ModalSignInEvent} represents the redirect url after user has signed in
     */
    private notifyParentAboutModalSignIn;
    /**
     * method called in case of exception on initialize.
     * if error is RideError, it redirects to the jump url from RideException.jump.
     * @return a rejected promise with the given ex
     */
    private verifyRideErrorException;
    /**
     * Same as verifyRideErrorExceptionStrict, but returns null if ex is not RideException
     */
    private verifyRideErrorExceptionStrict;
    /**
     * method called in case of exception on initialize.  if error type is CSRF, it calls the signOut methods
     */
    private verifyCsrfException;
    /**
     * method called after a successful call to the getTokenAndProfile method in order to process the token response
     * tokenProfile: TokenProfileResponse - contains the token fields and eventually the user profile
     * @returns Promise
     */
    private processTokenResponse;
    /**
     * restore the window hash value to the initial one
     */
    private restoreHash;
    /**
     * Exchange the user's access_token for a Transitory Access Code (TAC) for target client and scope
     * @see {@link https://wiki.corp.adobe.com/display/ims/Transitory+Authorization+Codes |Transitory Authorization Codes}
     * @param tacRequest {ITransitoryAuthorizationRequest}
     * @param externalParameters {IDictionary} object used in order to update the default api values
     */
    getTransitoryAuthorizationCode(tacRequest: ITransitoryAuthorizationRequest, externalParameters?: IDictionary): Promise<ITransitoryAuthorizationResponse>;
    /**
     * method used during initialization in order to get a ijt token
     * https://wiki.corp.adobe.com/display/ims/Implicit+Jump+Tokens
     * @returns {Promise<any>} ijt response
     * @param {string} ijt value used for token excahnge (other than the one from adobeid)
     * @usage adobeIMS.adobeIdData.ijt = 'ijtValue' followed by adobeIMS.initialize()
     */
    private exchangeIjt;
    /**
     * Allows a client to launch a system-browser and arrive at another IMS-integrated application
     * https://wiki.corp.adobe.com/pages/viewpage.action?spaceKey=ims&title=IMS+API+-+jumptoken
     * @param jumpTokenRequest {IJumpTokenRequest}
     * @param externalParameters {object} object used to override the default request values
     * @returns IJumpTokenResponse
     */
    jumpToken(jumpTokenRequest: IJumpTokenRequest, externalParameters?: IDictionary): Promise<IJumpTokenResponse>;
    getVerifierByKey(nonce: string): string;
    /**
     * The purpose is to sign in with a social account without navigating outside the page (i.e. via Ajax calls only)
     * @see {@link https://wiki.corp.adobe.com/pages/viewpage.action?pageId=1106020498} Social Headless API
     * @param socialHeadlessSignInRequest {ISocialHeadlessSignInRequest} containing the social provider and the token obtained
     * @param externalParameters {object} object used to override the default request values
     * @returns TokenProfileResponse with the response from the IJT exchange
     * Will initiate a signIn flow if the response is a ride error of type 'ride_AdobeID_social`
     */
    socialHeadlessSignIn(socialHeadlessSignInRequest: ISocialHeadlessSignInRequest, externalParameters?: IDictionary): Promise<TokenProfileResponse>;
    /**
     * Returns the account type from the stored profile.
     * If the profile is not available, it will throw an error.
     *
     * For guest accounts we don't have a profile, so it will always return 'guest'.
     */
    getAccountType(): string;
    /**
     * Returns the guest session expiration time.
     * The format is the number of seconds from Epoch.
     */
    getSessionExpiration(): number | undefined;
    /**
     * Users can jump between a web browser and a mobile/desktop application and must be able to do that seamlessly
     * without entering the authorization flow in the desktop application again.
     * https://wiki.corp.adobe.com/x/hEsEtw
     * @param jumpTokenToDeviceRequest {IJumpTokenToDeviceRequest}
     * @param externalParameters {object} object used to override the default request values
     * @returns IJumpTokenToDeviceResponse
     */
    jumpTokenToDevice(jumpTokenToDeviceRequest: IJumpTokenToDeviceRequest, externalParameters?: IDictionary): Promise<IJumpTokenToDeviceResponse>;
    private onSignOutEventReceived;
}
