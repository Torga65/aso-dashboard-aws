import { IDictionary } from "../../facade/IDictionary";
import { INonce } from './INonce';
export declare const ONE_HOUR: number;
/**
 * class used for the CSRF process
 */
export declare class CsrfService {
    /**
     * represents the Storage instance used during Csrf flow
     */
    private storageInstance;
    /**
     * represents the storage key used to save the nonce values for current client Id
     */
    private nonceStorageKey;
    /**
     *
     * @param clientId {String} the client id used for Csrf
     */
    constructor(clientId: string, instanceKey?: string);
    get storage(): Storage;
    /**
     * Starts the CSRF process by trying to save a random string value to available storage
     * @returns the nonce value
     */
    initialize(): string;
    /**
     *
     * @param nonceStorageValue represents the object used to store the nonce values
     * @param nonce represents the nonce value
     */
    addNonceToObject(nonceStorageValue: IDictionary, nonce: INonce): void;
    /**
     * clears the local storage keys older than 1h
     * @param nonceStorageValue local storage object used to store nonce
     */
    clearOlderNonceKeys(nonceStorageValue: IDictionary, olderThan?: number): IDictionary;
    /**
     * @param fragmentNonce represents the nonce value received after redirect from ims
     * @returns {boolean} true if nonce is valid, otherwise false
     */
    verify(fragmentNonce: string): boolean;
    /**
     *
     * @param nonceStorageValue represents the saved nonce values into the Storage
     * @param fragmentNonce is nonce value which will be removed from Storage
     */
    clearNonceValueFromStorage(nonceStorageValue: IDictionary, fragmentNonce: string): void;
    /**
     * Returns the nonce values from storage as an Object or null
     * @returns {IDictionary | null}
     */
    getNonceFromStorage(): IDictionary | null;
    /**
   * @param nonceValues the nonce values which will be saved to Storage
   */
    private saveNonceValuesToStorage;
    /**
     * function used to check if the local or session storage is available
     */
    isStorageAvailable(): boolean;
    /**
     * @function randomString
     * used to generate a random string during the initialization of Csrf process
     */
    static randomString: () => string;
    /**
     * generate random string based on crypto object
     */
    static cryptoRndomString(): string;
    /**
     * generate a key value pair used for nonce
     * @returns INonce object
     */
    static generateNonce: () => INonce;
}
