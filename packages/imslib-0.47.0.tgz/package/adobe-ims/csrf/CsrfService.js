"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var StorageFactory_1 = __importDefault(require("../../storage/StorageFactory"));
var MemoryStorage_1 = require("../../storage/MemoryStorage");
var ImsConstants_1 = require("../../constants/ImsConstants");
/**
 * nonce key used for store the Csrf nonce value
 */
var NONCE = 'nonce';
var NONCE_LENGTH = 16;
exports.ONE_HOUR = 60 * 60 * 3600;
var CSRF_VERIFIED = 'csrf_verified';
/**
 * class used for the CSRF process
 */
var CsrfService = /** @class */ (function () {
    /**
     *
     * @param clientId {String} the client id used for Csrf
     */
    function CsrfService(clientId, instanceKey) {
        if (instanceKey === void 0) { instanceKey = ImsConstants_1.AdobeIMSKey; }
        /**
         * represents the Storage instance used during Csrf flow
         */
        this.storageInstance = null;
        /**
         * represents the storage key used to save the nonce values for current client Id
         */
        this.nonceStorageKey = '';
        this.nonceStorageKey = "" + NONCE + instanceKey + clientId;
    }
    Object.defineProperty(CsrfService.prototype, "storage", {
        get: function () {
            if (!this.storageInstance) {
                this.storageInstance = StorageFactory_1.default.getAvailableStorage();
            }
            return this.storageInstance;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Starts the CSRF process by trying to save a random string value to available storage
     * @returns the nonce value
     */
    CsrfService.prototype.initialize = function () {
        window[CSRF_VERIFIED] = false;
        if (!this.isStorageAvailable()) {
            return '';
        }
        var nonce = CsrfService.generateNonce();
        var nonceStorageValue = this.getNonceFromStorage() || {};
        nonceStorageValue = this.clearOlderNonceKeys(nonceStorageValue);
        this.addNonceToObject(nonceStorageValue, nonce);
        this.saveNonceValuesToStorage(nonceStorageValue);
        return nonce.value;
    };
    /**
     *
     * @param nonceStorageValue represents the object used to store the nonce values
     * @param nonce represents the nonce value
     */
    CsrfService.prototype.addNonceToObject = function (nonceStorageValue, nonce) {
        nonceStorageValue[nonce.value] = nonce.expiry;
    };
    /**
     * clears the local storage keys older than 1h
     * @param nonceStorageValue local storage object used to store nonce
     */
    CsrfService.prototype.clearOlderNonceKeys = function (nonceStorageValue, olderThan) {
        if (olderThan === void 0) { olderThan = exports.ONE_HOUR; }
        var oneHourAgo = Date.now() - olderThan;
        var expiry = 0;
        Object.keys(nonceStorageValue).forEach(function (key) {
            expiry = parseInt(nonceStorageValue[key]);
            if (expiry < oneHourAgo) {
                delete nonceStorageValue[key];
            }
        });
        return nonceStorageValue;
    };
    /**
     * @param fragmentNonce represents the nonce value received after redirect from ims
     * @returns {boolean} true if nonce is valid, otherwise false
     */
    CsrfService.prototype.verify = function (fragmentNonce) {
        if (window[CSRF_VERIFIED] === true) {
            return true;
        }
        window[CSRF_VERIFIED] = true;
        if (!this.isStorageAvailable()) {
            return true;
        }
        var storageNonce = this.getNonceFromStorage();
        if (!storageNonce) {
            return false;
        }
        var nonceStorageValue = this.clearOlderNonceKeys(storageNonce);
        var isValidCsrf = (nonceStorageValue[fragmentNonce] || null) !== null;
        if (isValidCsrf) {
            this.clearNonceValueFromStorage(nonceStorageValue, fragmentNonce);
        }
        return isValidCsrf;
    };
    /**
     *
     * @param nonceStorageValue represents the saved nonce values into the Storage
     * @param fragmentNonce is nonce value which will be removed from Storage
     */
    CsrfService.prototype.clearNonceValueFromStorage = function (nonceStorageValue, fragmentNonce) {
        delete nonceStorageValue[fragmentNonce];
        this.saveNonceValuesToStorage(nonceStorageValue);
    };
    /**
     * Returns the nonce values from storage as an Object or null
     * @returns {IDictionary | null}
     */
    CsrfService.prototype.getNonceFromStorage = function () {
        var nonce = this.storage.getItem(this.nonceStorageKey);
        return nonce ? JSON.parse(nonce) : null;
    };
    /**
   * @param nonceValues the nonce values which will be saved to Storage
   */
    CsrfService.prototype.saveNonceValuesToStorage = function (nonceValues) {
        this.storage.setItem(this.nonceStorageKey, JSON.stringify(nonceValues));
    };
    /**
     * function used to check if the local or session storage is available
     */
    CsrfService.prototype.isStorageAvailable = function () {
        return !(this.storage instanceof MemoryStorage_1.MemoryStorage);
    };
    /**
     * generate random string based on crypto object
     */
    CsrfService.cryptoRndomString = function () {
        if (!window.crypto) {
            return '';
        }
        var array = new Uint32Array(3);
        window.crypto.getRandomValues(array);
        return array.join('').substr(0, NONCE_LENGTH);
    };
    /**
     * @function randomString
     * used to generate a random string during the initialization of Csrf process
     */
    CsrfService.randomString = function () {
        var cryptorandomString = CsrfService.cryptoRndomString();
        if (cryptorandomString) {
            return cryptorandomString;
        }
        var text = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for (var i = 0; i < NONCE_LENGTH; i++) {
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        }
        return text;
    };
    /**
     * generate a key value pair used for nonce
     * @returns INonce object
     */
    CsrfService.generateNonce = function () { return ({
        value: CsrfService.randomString(),
        expiry: new Date().getTime().toString()
    }); };
    return CsrfService;
}());
exports.CsrfService = CsrfService;
