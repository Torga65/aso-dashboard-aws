"use strict";
/**
 * interface used to store the parameters used by TokenAutoRefresh class
 */
Object.defineProperty(exports, "__esModule", { value: true });
