import { ITokenAutoRefreshParams } from "./ITokenAutoRefreshParams";
/**
 * class used for automatically refresh the token.
 * the refreshToken method is automatically triggered one minute before the token expires
 * if the user interacted with the page at all after the startAutoRefreshFlow was called.
 */
declare class TokenAutoRefresh {
    /**
     * represents the timer used to refresh the token before the last N minutes;
     */
    refreshTimerId: any;
    /**
     * Token Autorefresh parameters updated by the {@link startAutoRefreshFlow} method
     */
    refreshParameters?: ITokenAutoRefreshParams;
    /**
     * Holds the date of the last user interaction
     */
    lastUserInteraction: number;
    /**
     * Flag that the user was active at all during this refresh cycle
     */
    userActive: boolean;
    /**
     * Handler for user interactions
     * Initiates the Token Refresh one minute before it expires, if any interaction is detected
     * Returns immediately if the refresh is already scheduled
     * @returns
     */
    userInteractionHandler: () => void;
    /**
     * starts the autorefresh flow
     * @param autoRefreshParameters {@link ITokenAutoRefreshParams} parameters used for auto refresh flow
     */
    startAutoRefreshFlow(autoRefreshParameters: ITokenAutoRefreshParams): void;
    /**
    * Initializes the event listeners for user interaction
    * The function passed must be the member bound to this instance
    */
    private initializeDomEvents;
    /**
     * Clears event listeners
     */
    private clearDomEvents;
    /**
     * Returns the milliseconds interval from now to a given date minus N minutes
     * @param toDate represents the target date
     * @param nMinutes represents the number of minutes to substract from the target date
     * @returns the interval in milliseconds; if the resulting interval is <= 0,
     * this method returns nMinutes in ms
     */
    private fromNowToNMinutesBeforeDate;
}
declare const _default: TokenAutoRefresh;
export default _default;
