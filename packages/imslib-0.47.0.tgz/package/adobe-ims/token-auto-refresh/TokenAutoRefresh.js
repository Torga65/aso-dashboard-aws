"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var Log_1 = __importDefault(require("../../log/Log"));
/**
 * auto refresh minutes interval
 */
var ONE_MIN_MS = 60000;
var ONE_SECOND_MS = 1000;
var REFRESH_INTERVAL_BEFORE_EXPIRATION_MIN = 1;
var USER_INTERACTION_EVENTS = ['keyup', 'mousemove'];
/**
 * class used for automatically refresh the token.
 * the refreshToken method is automatically triggered one minute before the token expires
 * if the user interacted with the page at all after the startAutoRefreshFlow was called.
 */
var TokenAutoRefresh = /** @class */ (function () {
    function TokenAutoRefresh() {
        var _this = this;
        /**
         * Holds the date of the last user interaction
         */
        this.lastUserInteraction = Date.now();
        /**
         * Flag that the user was active at all during this refresh cycle
         */
        this.userActive = false;
        /**
         * Handler for user interactions
         * Initiates the Token Refresh one minute before it expires, if any interaction is detected
         * Returns immediately if the refresh is already scheduled
         * @returns
         */
        this.userInteractionHandler = function () {
            _this.lastUserInteraction = Date.now();
            _this.userActive = true;
        };
        /**
        * Initializes the event listeners for user interaction
        * The function passed must be the member bound to this instance
        */
        this.initializeDomEvents = function () {
            USER_INTERACTION_EVENTS.forEach(function (eventName) { return window.addEventListener(eventName, _this.userInteractionHandler); });
        };
        /**
         * Clears event listeners
         */
        this.clearDomEvents = function () {
            USER_INTERACTION_EVENTS.forEach(function (eventName) { return window.removeEventListener(eventName, _this.userInteractionHandler); });
        };
    }
    /**
     * starts the autorefresh flow
     * @param autoRefreshParameters {@link ITokenAutoRefreshParams} parameters used for auto refresh flow
     */
    TokenAutoRefresh.prototype.startAutoRefreshFlow = function (autoRefreshParameters) {
        var _this = this;
        var _a;
        if (!autoRefreshParameters || !autoRefreshParameters.expire
            || !autoRefreshParameters.refreshTokenMethod) {
            Log_1.default.info('Won\'t schedule token auto-refresh', !autoRefreshParameters, !autoRefreshParameters.expire, !autoRefreshParameters.refreshTokenMethod);
            return;
        }
        this.refreshParameters = autoRefreshParameters;
        if (this.refreshTimerId) {
            Log_1.default.info('Auto-refresh timer already set, clearing');
            clearTimeout(this.refreshTimerId);
        }
        this.clearDomEvents();
        this.initializeDomEvents();
        var interval = this.fromNowToNMinutesBeforeDate((_a = this.refreshParameters) === null || _a === void 0 ? void 0 : _a.expire, REFRESH_INTERVAL_BEFORE_EXPIRATION_MIN);
        Log_1.default.info('Auto-refresh timer will run after (seconds)', interval / ONE_SECOND_MS);
        this.refreshTimerId = setTimeout(function () {
            var _a, _b;
            if (autoRefreshParameters.isGuest) {
                (_a = _this.refreshParameters) === null || _a === void 0 ? void 0 : _a.refreshTokenMethod({}, true);
                Log_1.default.info('Auto-refresh performed, guest user');
            }
            else if (_this.userActive) {
                var userInactiveSince = Math.floor((Date.now() - _this.lastUserInteraction) / ONE_SECOND_MS);
                (_b = _this.refreshParameters) === null || _b === void 0 ? void 0 : _b.refreshTokenMethod({ userInactiveSince: userInactiveSince }, true);
                Log_1.default.info('Auto-refresh performed, user was inactive for (seconds)', userInactiveSince);
            }
            else {
                Log_1.default.info('Auto-refresh skipped, user was never active');
            }
        }, interval);
    };
    /**
     * Returns the milliseconds interval from now to a given date minus N minutes
     * @param toDate represents the target date
     * @param nMinutes represents the number of minutes to substract from the target date
     * @returns the interval in milliseconds; if the resulting interval is <= 0,
     * this method returns nMinutes in ms
     */
    TokenAutoRefresh.prototype.fromNowToNMinutesBeforeDate = function (toDate, nMinutes) {
        var interval = toDate.getTime() - Date.now() - nMinutes * ONE_MIN_MS;
        if (interval <= 0) {
            return nMinutes * ONE_MIN_MS;
        }
        return interval;
    };
    return TokenAutoRefresh;
}());
exports.default = new TokenAutoRefresh();
