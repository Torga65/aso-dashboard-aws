"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var StorageFactory_1 = __importDefault(require("./../storage/StorageFactory"));
var ImsConstants_1 = require("../constants/ImsConstants");
var ProfileException_1 = require("./ProfileException");
var HttpErrorResponse_1 = require("../error-handlers/HttpErrorResponse");
var ScopeUtil_1 = require("../util/ScopeUtil");
/**
 * class used to implement the profile methods
 */
var ProfileService = /** @class */ (function () {
    function ProfileService(profileServiceRequest) {
        this.profileServiceRequest = profileServiceRequest;
        this.storage = StorageFactory_1.default.getStorageByName(ImsConstants_1.STORAGE_MODE.SessionStorage);
    }
    /**
     *
     * @param token {string} - the string used to obtain the profile information
     */
    ProfileService.prototype.getProfile = function (token) {
        var _this = this;
        var _a = this.profileServiceRequest, clientId = _a.clientId, imsApis = _a.imsApis;
        var sessionProfile = this.getProfileFromStorage();
        if (sessionProfile) {
            return Promise.resolve(sessionProfile);
        }
        return imsApis.getProfile({
            client_id: clientId,
            token: token
        }).then(function (profile) {
            // const { data: profile } = response;
            if (!profile) {
                throw new ProfileException_1.ProfileException('NO profile response');
            }
            if (Object.keys(profile).length === 0) {
                throw new ProfileException_1.ProfileException('NO profile value');
            }
            _this.saveProfileToStorage(profile);
            return Promise.resolve(profile);
        })
            .catch(function (ex) {
            if (ex instanceof HttpErrorResponse_1.HttpErrorResponse) {
                return Promise.reject(ex);
            }
            _this.removeProfile();
            return Promise.reject(ex);
        });
    };
    /**
    * private method used to compose the key used for storage
    * @param clientId
    * @param scope
    * @param isReAuth default false
    */
    ProfileService.prototype.getProfileStorageKey = function () {
        var _a = this.profileServiceRequest, clientId = _a.clientId, scope = _a.scope;
        var isReAuth = false;
        return ImsConstants_1.PROFILE_STORAGE_KEY + "/" + clientId + "/" + isReAuth + "/" + ScopeUtil_1.sortScopes(scope);
    };
    /**
     * read the profile from session storage
     */
    ProfileService.prototype.getProfileFromStorage = function () {
        var profileStorageKey = this.getProfileStorageKey();
        var sessionProfile = this.storage.getItem(profileStorageKey);
        return sessionProfile && JSON.parse(sessionProfile);
    };
    /**
     *
     * @param profile {Object} object containing the profile information
     * save the profile to session storage
     */
    ProfileService.prototype.saveProfileToStorage = function (profile) {
        var profileStorageKey = this.getProfileStorageKey();
        this.storage.setItem(profileStorageKey, JSON.stringify(profile));
    };
    /**
     * remove the profile value from the SessionStorage
     */
    ProfileService.prototype.removeProfile = function () {
        var profileStorageKey = this.getProfileStorageKey();
        this.storage.removeItem(profileStorageKey);
    };
    /**
     *
     * @param userId {string} represents the user id of the new logged user
     * @returns { boolean } - true if the profile was removed, otherwise false
     */
    ProfileService.prototype.removeProfileIfOtherUser = function (userId) {
        if (!userId) {
            return;
        }
        var profile = this.getProfileFromStorage();
        if (!profile || profile.userId === userId) {
            return;
        }
        this.removeProfile();
    };
    return ProfileService;
}());
exports.ProfileService = ProfileService;
