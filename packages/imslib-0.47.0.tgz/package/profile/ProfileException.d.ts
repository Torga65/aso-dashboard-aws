import { IErrorType } from "../adobe-id/IErrorType";
/**
 * class used to trigger profile errors
 */
export declare class ProfileException {
    message: null;
    errorType: IErrorType;
    constructor(message: any);
}
