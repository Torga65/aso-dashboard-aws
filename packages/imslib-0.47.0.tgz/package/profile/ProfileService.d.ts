import { IServiceRequest } from '../adobe-ims/facade/IServiceRequest';
/**
 * class used to implement the profile methods
 */
export declare class ProfileService {
    /**
    * session storage instance used to manage the profile information
    */
    storage: Storage;
    profileServiceRequest: IServiceRequest;
    constructor(profileServiceRequest: IServiceRequest);
    /**
     *
     * @param token {string} - the string used to obtain the profile information
     */
    getProfile(token: string): Promise<any>;
    /**
    * private method used to compose the key used for storage
    * @param clientId
    * @param scope
    * @param isReAuth default false
    */
    private getProfileStorageKey;
    /**
     * read the profile from session storage
     */
    getProfileFromStorage(): any;
    /**
     *
     * @param profile {Object} object containing the profile information
     * save the profile to session storage
     */
    saveProfileToStorage(profile: any): void;
    /**
     * remove the profile value from the SessionStorage
     */
    removeProfile(): void;
    /**
     *
     * @param userId {string} represents the user id of the new logged user
     * @returns { boolean } - true if the profile was removed, otherwise false
     */
    removeProfileIfOtherUser(userId: string): void;
}
