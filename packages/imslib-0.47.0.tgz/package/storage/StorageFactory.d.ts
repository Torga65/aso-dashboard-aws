import { MemoryStorage } from './MemoryStorage';
import { STORAGE_MODE } from '../constants/ImsConstants';
/**
 * A cross-browser way to use `sessionStorage`
 *
 * @exports storage
 * @requires MemoryStorage
 */
declare class StorageFactory {
    memoryStorageInstance: MemoryStorage | null;
    get memoryStorage(): MemoryStorage;
    /**
    *
    * @param storageName represents the storage name
    * @returns the local or session storage; in case there is a problem with storage, the memory storage is returned
    */
    getStorageByName(storageName: STORAGE_MODE): Storage;
    /**
     * method used to get the avilable storage and to give the possibility to mock the behaviour
     * @param storageName the storage name used to get the storage
     * @returns Storage or null
     */
    getStorageInstanceByName(storageName: STORAGE_MODE): Storage | null;
    /**
     * returns the available storage; the priority is local storage and after that the session storage
     * if no local or session storage is available, the Memory Storage is returned
     */
    getAvailableStorage(): Storage;
    /**
     *
     * @param storage represents the storage instance
     * @returns true if storage is working as expected otherwise false
     */
    verifyStorage(storage: Storage): boolean;
}
declare const _default: StorageFactory;
export default _default;
