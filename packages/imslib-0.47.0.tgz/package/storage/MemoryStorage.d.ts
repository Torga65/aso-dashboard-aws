import { IDictionary } from './../facade/IDictionary';
/**
 * In-Memory polyFill for localStorage and sessionStorage.
 *
 * @constructor
 * @description Needed for Mac and iOS Safari (v <= 10) in Private Mode. Note that this object doesn't actually
 * persist data across refresh, it just implements the [Storage]{@link external:Storage} interface.
 * @exports memoryStorage
 */
export declare class MemoryStorage implements Storage {
    /**
     * @type {!Object}
     */
    data: IDictionary;
    /**
     * property added in order to be compatible with Storage class
     */
    length: number;
    /**
     * clear the memory data
     */
    clear(): void;
    /**
     * @param key {String} represents the used key to get a value
     * @returns {Object} the value associated with the input key
     */
    getItem(key: string): any;
    /**
     *
     * @param key {string} represent the key which will be removed from memory
     * @returns {boolean} true if the key is removed otherwise false
     */
    removeItem(key: string): boolean;
    /**
     * @key {String} - the used key to store a value into memory
     * @value {any} - value associated with the input key
     */
    setItem(key: string, value: string): void;
    /**
     * @param index { number } represents the key index
     * method added only to be compatible with Storage class
     * NOT USED
     */
    [name: string]: any;
    key(index: number): string | null;
}
