"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var MemoryStorage_1 = require("./MemoryStorage");
var ImsConstants_1 = require("../constants/ImsConstants");
var Log_1 = __importDefault(require("../log/Log"));
/**
 * A cross-browser way to use `sessionStorage`
 *
 * @exports storage
 * @requires MemoryStorage
 */
var StorageFactory = /** @class */ (function () {
    function StorageFactory() {
        this.memoryStorageInstance = null;
    }
    Object.defineProperty(StorageFactory.prototype, "memoryStorage", {
        get: function () {
            if (!this.memoryStorageInstance) {
                this.memoryStorageInstance = new MemoryStorage_1.MemoryStorage();
            }
            return this.memoryStorageInstance;
        },
        enumerable: true,
        configurable: true
    });
    /**
    *
    * @param storageName represents the storage name
    * @returns the local or session storage; in case there is a problem with storage, the memory storage is returned
    */
    StorageFactory.prototype.getStorageByName = function (storageName) {
        var storageInstance = this.getStorageInstanceByName(storageName);
        if (!storageInstance) {
            return this.memoryStorage;
        }
        return this.verifyStorage(storageInstance) ? storageInstance : this.memoryStorage;
    };
    /**
     * method used to get the avilable storage and to give the possibility to mock the behaviour
     * @param storageName the storage name used to get the storage
     * @returns Storage or null
     */
    StorageFactory.prototype.getStorageInstanceByName = function (storageName) {
        if (storageName === ImsConstants_1.STORAGE_MODE.MemoryStorage) {
            return this.memoryStorage;
        }
        try {
            return storageName === ImsConstants_1.STORAGE_MODE.LocalStorage ? window.localStorage : window.sessionStorage;
        }
        catch (ex) {
            Log_1.default.warn('Please change your cookies settings in order to allow local data to be set');
            return null;
        }
    };
    /**
     * returns the available storage; the priority is local storage and after that the session storage
     * if no local or session storage is available, the Memory Storage is returned
     */
    StorageFactory.prototype.getAvailableStorage = function () {
        var storage = this.getStorageByName(ImsConstants_1.STORAGE_MODE.LocalStorage);
        if (storage instanceof MemoryStorage_1.MemoryStorage) {
            return this.getStorageByName(ImsConstants_1.STORAGE_MODE.SessionStorage);
        }
        return storage;
    };
    /**
     *
     * @param storage represents the storage instance
     * @returns true if storage is working as expected otherwise false
     */
    StorageFactory.prototype.verifyStorage = function (storage) {
        var storageKey = 'test';
        try {
            storage.setItem(storageKey, 'true');
            var storageValue = storage.getItem(storageKey);
            if (storageValue !== 'true') {
                return false;
            }
            storage.removeItem(storageKey);
            return true;
        }
        catch (ex) {
            return false;
        }
    };
    return StorageFactory;
}());
exports.default = new StorageFactory();
