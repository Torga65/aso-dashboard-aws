/**
 * Wrapper for <code>console</code>. Checks <code>console</code> is available and <code>debug</code> Mode is enabled.
 *
 * @exports log
 *
 */
declare class Log {
    private logEnabled;
    enableLogging(): void;
    disableLogging(): void;
    /**
     * Wrapper function.
     *
     * @param {String} method - Which <code>console</code> method to use.
     * @param {*} args - Arguments object
     *
     * @private
     */
    print: (method: Function, args: any) => void;
    /**
     * Writes an error to the console when the evaluated expression is false.
     *
     * @example
     * log.assert(1 == 2, "Counting is hard.");
     *
     * @param {Boolean} expression - Expression to evaluate.
     * @param {String} message - Message to print if <code>epxression</code> is <code>false</code>.
     *
     * @static
     */
    assert: (val: string | boolean, message: any) => void;
    /**
     * Writes an error to the console when the evaluated expression is false.
     *
     * @example
     * log.assert(1 == 2, "Counting is hard.");
     *
     * @param {Boolean} expression - Expression to evaluate.
     * @param {String} message - Message to print if <code>epxression</code> is <code>false</code>.
     *
     * @static
     */
    assertCondition: (condition: Function, message: any) => void;
    /**
     * Prints a message similar to <code>console.log()</code>, styles the message like an error, and includes a stack
     * trace from where the method wasval, called.
     *
     * @see {@link https://developers.google.com/web/tools/chrome-devtools/console/#filtering_the_console_output | Filtering the Console output}
     *
     * @example
     * log.error("Define window.adobeid", "would you?!");
     * @param {String} message - Message to print.
     */
    error: (...args: any[]) => void;
    /**
     * logs a warnig message
     */
    warn: (...args: any[]) => void;
    /**
     * Prints a message like <code>console.log()</code> but also shows an icon (blue circle with white "i") next to the
     * output.
     *
     * <code>console.info()</code> can be filtered in the Console, whereas <code>console.log()</code> can not.
     *
     * @example
     * log.info("Imslib.js Ready", "to Rumble");
     *
     * @param {String} message - Message to print.
     *
     * @static
     */
    info: (...args: any[]) => void;
}
declare const _default: Log;
export default _default;
